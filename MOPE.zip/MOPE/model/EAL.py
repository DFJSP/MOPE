import torch
import copy
import random
import time
import numpy as np


class EAL():
    def __init__(self, model_paras):
        """
        反对称矩阵 A -> Q 正交矩阵
        进化算法对 A 进行迭代进化
        利用 Q 计算对应的目标值，最终得到Q
        """
        self.opes_feature_dim = model_paras["opes_feat_dim"]
        self.mas_feature_dim = model_paras["mas_feat_dim"]
        self.opes_num_params = self.opes_feature_dim * (self.opes_feature_dim-1) // 2
        self.mas_num_params = self.mas_feature_dim * (self.mas_feature_dim - 1) // 2
        self.device = model_paras["device"]
        self.omega_scope = model_paras["omega_scope"]

        self.evolve_iteration = model_paras["evolve_iteration"]
        self.num_pop = model_paras["num_pop"]
        self.num_inds = model_paras["num_individual"]
        self.pop_idxes = torch.arange(self.num_pop)
        self.inds_idxes = torch.arange(self.num_inds)

        self.batch_size = model_paras["batch_size"]
        self.num_jobs = model_paras["num_jobs"]
        self.num_mas = model_paras["num_mas"]

        self.work_power = model_paras["work_power"]
        self.unwork_power = model_paras["unwork_power"]
        time_of_electric = model_paras["time_of_electric"]
        self.time_of_electric = torch.tensor(time_of_electric).float()
        self.score_weight = model_paras["score_weight"]
        # self.time_of_electric = (torch.tensor(time_of_electric).float())

        self.select_score = model_paras["select_score"]
        self.stat = {
            'gene_div': {'mean': 0., 'std': 1.},
            'obj_div': {'mean': 0., 'std': 1.},
            'conv': {'mean': 0., 'std': 1.}
        }
        self.stat_alpha = model_paras["stat_alpha"]

        # 基因交叉参数
        self.para_global_elite = model_paras["para_global_elite"]               # 种群精英引导
        self.para_inds_parent_elite = model_paras["para_inds_parent_elite"]     # 个体精英引导
        self.para_crossover_stride = model_paras["para_crossover_stride"]       # 个体交叉间隔步数

        # 基因突变参数
        self.para_mut_prob = model_paras["para_mut_prob"]           # 个体发生突变的概率
        self.para_mut_ratio = model_paras["para_mut_ratio"]         # 每个个体中突变基因个数
        self.mut_strength = model_paras["mut_strength"]             # 突变扰动

        # 1.初始化种群opes: num_pops*num_inds*36, mas: num_pops*num_inds*28
        self.omega_opes, self.omega_mas = self.initpopvfit()
        print("----------完成初始化-----------")

        # 记录训练的种群分数
        self.pop_score = []

    def initpopvfit(self):
        # 初始化 omega（自由参数）
        omega_opes = torch.randn(size=(self.num_pop, self.num_inds, self.opes_num_params), device=self.device).uniform_(-self.omega_scope, self.omega_scope)
        omega_mas = torch.randn(size=(self.num_pop, self.num_inds, self.mas_num_params), device=self.device).uniform_(-self.omega_scope, self.omega_scope)

        return omega_opes, omega_mas

    def A_to_Q(self, omega_opes, omega_mas):
        A_opes = self.omega_to_A(omega_opes, self.opes_feature_dim)
        A_mas = self.omega_to_A(omega_mas, self.mas_feature_dim)

        Q_opes = torch.matrix_exp(A_opes)
        Q_mas = torch.matrix_exp(A_mas)

        return Q_opes, Q_mas

    def omega_to_A(self, omega, d):
        """
            omega: (..., D)
            return: (..., d, d)  skew-symmetric
        """
        *batch, D = omega.shape
        A = torch.zeros(*batch, d, d, device=omega.device)

        idx = torch.triu_indices(d, d, offset=1, device=omega.device)
        A[..., idx[0], idx[1]] = omega
        A[..., idx[1], idx[0]] = -omega
        return A

    def MPCE(self, state):

        self.env_state = state

        omega_opes = self.omega_opes.clone()
        omega_mas = self.omega_mas.clone()

        # 计算初始目标值
        # 对环境初始化设置，为每个种群的每个个体创建env
        self.reset_env(state=self.env_state)
        objective = self.calculate(omega_opes, omega_mas)

        # 对每个种群找最优解
        self.reset_archive()
        self.get_best(omega_opes, omega_mas, objective)

        # 评价种群
        self.evaluate_pop(omega_opes, omega_mas, objective)

        # 交叉变异
        begin_time = time.time()
        for i in range(self.evolve_iteration):
            print(f"--------------{i}代---------------")

            # 1. omega_opes\omega_mas基因交叉变异
            star_time = time.time()
            omega_opes, omega_mas, objective = self.crossover(omega_opes, omega_mas, objective)
            cross_time = time.time()-star_time
            print(f"----{i}---Complete omega_opes-omega_mas crossover: {round(cross_time, 4)}-----")

            # 2. omega_opes\omega_mas基因突变变异
            star_time_2 = time.time()
            omega_opes, omega_mas, objective = self.mutation(omega_opes, omega_mas, objective)
            mut_time = time.time() - star_time_2
            print(f"----{i}---Complete omega_opes-omega_mas mutation: {round(mut_time, 4)}-----")

            # 3.评价种群
            self.evaluate_pop(omega_opes, omega_mas, objective)
            self.get_best(omega_opes, omega_mas, objective)

        pop_time = time.time() - begin_time
        print(f"-----------Complete {self.evolve_iteration}: {round(pop_time, 4)}-------------")

        self.omega_opes = omega_opes.clone()
        self.omega_mas = omega_mas.clone()

        # 处理种群分数信息 num_pop*iter*4
        pop_score = torch.stack(self.pop_score).transpose(0, 1)

        return self.omega_opes, self.omega_mas, pop_score

    def mutation(self, omega_opes, omega_mas, objective):

        n_omega_opes = omega_opes.clone()
        n_omega_mas = omega_mas.clone()

        # 1. 哪些个体发生突变
        mut_ind_mask_opes = (torch.rand(self.num_pop, self.num_inds, device=self.device) < self.para_mut_prob)  # [P, I]
        mut_ind_mask_mas = (torch.rand(self.num_pop, self.num_inds, device=self.device) < self.para_mut_prob)  # [P, I]

        # 2. 确定突变位置（每个个体 K 个）
        K_opes = max(1, int(self.para_mut_ratio * self.opes_num_params))
        K_mas = max(1, int(self.para_mut_ratio * self.mas_num_params))

        # 3. 突变位置
        mut_pos_opes = torch.randint(0, self.opes_num_params, (self.num_pop, self.num_inds, K_opes), device=self.device)  # [P, I, K]
        mut_pos_mas = torch.randint(0, self.mas_num_params, (self.num_pop, self.num_inds, K_mas), device=self.device)  # [P, I, K]

        # 4. 生成扰动幅度（加 / 减）
        delta_opes = torch.empty(
            (self.num_pop, self.num_inds, K_opes), device=self.device).uniform_(-self.mut_strength, self.mut_strength)
        delta_mas = torch.empty(
            (self.num_pop, self.num_inds, K_mas), device=self.device).uniform_(-self.mut_strength, self.mut_strength)

        # 5. 执行突变（只对 mask=True 的个体）
        for k in range(K_opes):
            idx = mut_pos_opes[:, :, k]
            n_omega_opes[
                torch.arange(self.num_pop)[:, None],
                torch.arange(self.num_inds)[None, :], idx
            ] += delta_opes[:, :, k] * mut_ind_mask_opes

        for k in range(K_mas):
            idx = mut_pos_mas[:, :, k]
            n_omega_mas[
                torch.arange(self.num_pop)[:, None],
                torch.arange(self.num_inds)[None, :],
                idx
            ] += delta_mas[:, :, k] * mut_ind_mask_mas

        # 6. 裁剪到合法范围
        n_omega_opes.clamp_(-self.omega_scope, self.omega_scope)
        n_omega_mas.clamp_(-self.omega_scope, self.omega_scope)

        # 7. 计算opes突变后目标值
        self.reset_env(state=self.env_state)
        objective_1 = self.calculate(n_omega_opes, omega_mas)

        parent_score = objective.sum(dim=-1)
        child_score_1 = objective_1.sum(dim=-1)

        replace_mask_opes = child_score_1 < parent_score

        next_omega_opes = torch.where(replace_mask_opes.unsqueeze(-1), n_omega_opes, omega_opes)
        next_objective = torch.where(replace_mask_opes.unsqueeze(-1), objective_1, objective)

        # 8. 计算mas突变后目标值
        self.reset_env(state=self.env_state)
        objective_2 = self.calculate(next_omega_opes, n_omega_mas)

        next_score = next_objective.sum(dim=-1)
        child_score_2 = objective_2.sum(dim=-1)

        replace_mask_mas = child_score_2 < next_score

        next_omega_mas = torch.where(replace_mask_mas.unsqueeze(-1), n_omega_mas, omega_mas)
        next_objective = torch.where(replace_mask_mas.unsqueeze(-1), objective_2, next_objective)

        omega_opes = next_omega_opes
        omega_mas = next_omega_mas
        objective = next_objective

        return omega_opes, omega_mas, objective


    def reset_archive(self):
        self.pop_pareto_archives = [
            {"opes": None, "mas": None, "obj": None}
            for _ in range(self.num_pop)
        ]
        self.global_pareto_archives = {
            "opes": None,
            "mas": None,
            "obj": None
        }

    def crossover(self, omega_opes, omega_mas, objective):
        """
        多种群基因交叉变异
        """
        # 1. 每个种群是否使用 global elitee
        pop_score = self.pop_score[-1][:, -1]
        use_global_elite = (pop_score < self.para_global_elite).view(self.num_pop, 1, 1)

        # 2. global archive → 每个 (pop, ind) 随机一个 elite
        g_opes, g_mas, _ = self.global_pareto_archives.values()
        g_idx = torch.randint(0, g_opes.size(0), (self.num_pop, self.num_inds), device=self.device)
        global_elite_ope = g_opes[g_idx]        # [P, I, D_ope]
        global_elite_mas = g_mas[g_idx]         # [P, I, D_mas]

        # 3. pop archive → 每个 (pop, ind) 随机一个 elite
        pop_elite_ope = []
        pop_elite_mas = []
        for p in range(self.num_pop):
            p_opes, p_mas, _ = self.pop_pareto_archives[p].values()
            idx = torch.randint(0, p_opes.size(0), (self.num_inds,), device=self.device)
            pop_elite_ope.append(p_opes[idx].unsqueeze(0))      # [1, I, D]
            pop_elite_mas.append(p_mas[idx].unsqueeze(0))
        pop_elite_ope = torch.cat(pop_elite_ope, dim=0)          # [P, I, D]
        pop_elite_mas = torch.cat(pop_elite_mas, dim=0)

        # 4. elite 来源选择（global / pop）
        elite_ope = torch.where(use_global_elite, global_elite_ope, pop_elite_ope)
        elite_mas = torch.where(use_global_elite, global_elite_mas, pop_elite_mas)

        # 5. 随机父代（pop 内）
        rand_idx = torch.randint(0, self.num_inds, (self.num_pop, self.num_inds), device=self.device)
        rand_parent_ope = omega_opes[torch.arange(self.num_pop).view(self.num_pop, 1), rand_idx]
        rand_parent_mas = omega_mas[torch.arange(self.num_pop).view(self.num_pop, 1), rand_idx]

        # 6. elite / random 混合
        use_elite_parent = (torch.rand(self.num_pop, self.num_inds, 1, device=self.device) < self.para_inds_parent_elite)
        parent_1_opes = torch.where(use_elite_parent, elite_ope, rand_parent_ope)
        parent_1_mas = torch.where(use_elite_parent, elite_mas, rand_parent_mas)

        # 7. parent 2 保持原个体
        parent_2_opes = omega_opes
        parent_2_mas = omega_mas

        # 8. 交叉变异
        n_omega_opes, _, n_objective = self.func_opes(parent_1_opes, parent_2_opes, parent_2_mas, objective)
        _, n_omega_mas, objective = self.func_mas(parent_1_mas, parent_2_mas, n_omega_opes, n_objective)

        return n_omega_opes, n_omega_mas, n_objective

    def func_mas(self, parent_1_mas, parent_2_mas, parent_opes, parent_objective):

        # 等间隔交叉，每个父代对，stride 固定，offset 每个个体不同
        # 1. 为每个个体生成偏移量
        # [P, I]
        offset = torch.randint(low=0, high=self.para_crossover_stride, size=(self.num_pop, self.num_inds), device=self.device)

        pos = torch.arange(self.mas_num_params, device=self.device)
        cross_mask = ((pos.view(1, 1, self.mas_num_params) - offset.unsqueeze(-1)) % self.para_crossover_stride == 0)       # [P, I, D]

        child_1_mas = torch.where(cross_mask, parent_1_mas, parent_2_mas)
        child_2_mas = torch.where(cross_mask, parent_2_mas, parent_1_mas)

        # 计算目标值
        self.reset_env(state=self.env_state)
        objective_1 = self.calculate(parent_opes, child_1_mas)

        self.reset_env(state=self.env_state)
        objective_2 = self.calculate(parent_opes, child_2_mas)

        # 目标值直接加和
        # [P, I]
        score_parent = parent_objective.sum(dim=-1)
        score_1 = objective_1.sum(dim=-1)
        score_2 = objective_2.sum(dim=-1)

        # [P, I, 3]
        score_stack = torch.stack([score_parent, score_1, score_2], dim=-1)
        # [P, I]
        best_idx = score_stack.argmin(dim=-1)
        # [P, I, D, 3]
        mas_stack = torch.stack([parent_2_mas, child_1_mas, child_2_mas], dim=-1)
        # [P, I, D]
        next_mas = torch.gather(
            mas_stack,
            dim=-1,
            index=best_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, self.mas_num_params, 1)).squeeze(-1)
        # [P, I, 3]
        obj_stack = torch.stack([parent_objective, objective_1, objective_2], dim=-2)

        next_objective = torch.gather(
            obj_stack,
            dim=-2,
            index=best_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, 1, 3)).squeeze(-2)

        omega_opes = parent_opes
        omega_mas = next_mas
        objective = next_objective

        return omega_opes, omega_mas, objective

    def func_opes(self, parent_1_opes, parent_2_opes, parent_mas, parent_objective):

        # 等间隔交叉，每个父代对，stride 固定，offset 每个个体不同
        # 1. 为每个个体生成偏移量
        # [P, I]
        offset = torch.randint(low=0, high=self.para_crossover_stride, size=(self.num_pop, self.num_inds), device=self.device)
        pos = torch.arange(self.opes_num_params, device=self.device)
        # [P, I, D]
        cross_mask = ((pos.view(1, 1, self.opes_num_params) - offset.unsqueeze(-1)) % self.para_crossover_stride == 0)
        child_1_opes = torch.where(cross_mask, parent_1_opes, parent_2_opes)
        child_2_opes = torch.where(cross_mask, parent_2_opes, parent_1_opes)

        # 计算目标值
        self.reset_env(state=self.env_state)
        objective_1 = self.calculate(child_1_opes, parent_mas)

        self.reset_env(state=self.env_state)
        objective_2 = self.calculate(child_2_opes, parent_mas)

        # 目标值直接加和
        # [P, I]
        score_parent = parent_objective.sum(dim=-1)
        score_1 = objective_1.sum(dim=-1)
        score_2 = objective_2.sum(dim=-1)

        # [P, I, 3]
        score_stack = torch.stack([score_parent, score_1, score_2], dim=-1)
        # [P, I]，0=parent, 1=child1, 2=child2
        best_idx = score_stack.argmin(dim=-1)
        # [P, I, D, 3]
        opes_stack = torch.stack([parent_2_opes, child_1_opes, child_2_opes], dim=-1)
        # [P, I, D]
        next_opes = torch.gather(
            opes_stack,
            dim=-1,
            index=best_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, self.opes_num_params, 1)).squeeze(-1)
        # [P, I, 3]
        obj_stack = torch.stack([parent_objective, objective_1, objective_2], dim=-2)

        next_objective = torch.gather(
            obj_stack,
            dim=-2,
            index=best_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, 1, 3)).squeeze(-2)

        omega_opes = next_opes
        omega_mas = parent_mas
        objective = next_objective

        return omega_opes, omega_mas, objective


    def evaluate_pop(self, omega_opes, omega_mas, objective):

        # 拼接基因
        genes = torch.cat([omega_opes.float(), omega_mas.float()], dim=-1)  # [P, I, L]

        # ---------- 1. 基因多样性(中心距离)----------
        center = genes.mean(dim=1, keepdim=True)
        gene_div = torch.norm(genes - center, dim=-1).mean(dim=1)  # [P]

        # ---------- 2. 目标多样性 ---------
        obj_norm = objective / (objective.max(dim=1, keepdim=True).values + 1e-8)
        obj_div = obj_norm.std(dim=1).mean(dim=-1)  # [P]

        # ---------- 3. 收敛性----------
        conv = objective.mean(dim=1).mean(dim=-1)  # [P]

        # --- 更新统计 ---
        self.update_running_stat('gene_div', gene_div)
        self.update_running_stat('obj_div', obj_div)
        self.update_running_stat('conv', conv)

        # --- 归一化 ---
        gene_div_n = self.normalize('gene_div', gene_div)
        obj_div_n = self.normalize('obj_div', obj_div)
        conv_n = self.normalize('conv', conv)

        # ---------- 4. 综合得分 ----------
        score = (gene_div_n * self.score_weight[0] + obj_div_n * self.score_weight[1] - conv_n * self.score_weight[2])

        all_score = torch.stack([gene_div, obj_div, conv, score], dim=0).transpose(0, 1)

        self.pop_score.append(all_score)

    def update_running_stat(self, name, x):
        mean = x.mean().detach()
        std = x.std().detach() + 1e-8

        self.stat[name]['mean'] = ( (1 - self.stat_alpha) * self.stat[name]['mean'] + self.stat_alpha * mean)
        self.stat[name]['std'] = ( (1 - self.stat_alpha) * self.stat[name]['std'] + self.stat_alpha * std)

    def normalize(self, name, x):
        return (x - self.stat[name]['mean']) / self.stat[name]['std']

    def get_best(self, omega_opes, omega_mas, objective):
        """
            每代：
            1 pop 内 Pareto
            2 pop archive 累积
            3 archive 去重 + Pareto
            4 global archive 由 pop archive 合并得到
        """
        # ---------- 1. pop 内 Pareto（并行） ----------
        # 根据目标值pareto排序
        # [P, I, M]->[P, I, 1, M] (被比较者i 主)
        pop_obj_i = objective.unsqueeze(2)
        # [P, I, M]->[P, 1, I, M] (比较者j 副)
        pop_obj_j = objective.unsqueeze(1)
        # j <= i (逐目标)
        pop_less_equal = pop_obj_j <= pop_obj_i  # [P, I, I, M]
        # j < i (至少一个目标)
        pop_strictly_less = pop_obj_j < pop_obj_i  # [P, I, I, M]
        # True: j dominates i
        pop_dominates = pop_less_equal.all(dim=-1) & pop_strictly_less.any(dim=-1)
        # dominates[p, i, j] == True : j 支配 i
        # i 是否被任何 j 支配
        pop_dominated = pop_dominates.any(dim=-1)  # [P, I]
        # pop Pareto front
        pop_pareto_mask = ~pop_dominated

        # ---------- 2. 更新 pop archive ----------
        p_idx, i_idx = pop_pareto_mask.nonzero(as_tuple=True)

        for p in range(self.num_pop):
            mask = (p_idx == p)
            if not mask.any():
                continue
            inds = i_idx[mask]

            cur_opes = omega_opes[p, inds].detach()
            cur_mas = omega_mas[p, inds].detach()
            cur_obj = objective[p, inds].detach()

            arch = self.pop_pareto_archives[p]

            if arch["opes"] is None:
                arch["opes"] = cur_opes
                arch["mas"] = cur_mas
                arch["obj"] = cur_obj
            else:
                arch["opes"] = torch.cat([arch["opes"], cur_opes], dim=0)
                arch["mas"] = torch.cat([arch["mas"], cur_mas], dim=0)
                arch["obj"] = torch.cat([arch["obj"], cur_obj], dim=0)

        # ---------- 3. pop archive：去重 + Pareto ----------
        for p in range(self.num_pop):
            arch = self.pop_pareto_archives[p]
            if arch["opes"] is None:
                continue
            opes, mas, obj = self.unique_and_pareto(arch["opes"], arch["mas"], arch["obj"])
            self.pop_pareto_archives[p] = {
                "opes": opes,
                "mas": mas,
                "obj": obj
            }
        # ---------- 4. 构建 global archive ----------
        opes_list, mas_list, obj_list = [], [], []

        for arch in self.pop_pareto_archives:
            if arch["opes"] is None:
                continue
            opes_list.append(arch["opes"])
            mas_list.append(arch["mas"])
            obj_list.append(arch["obj"])

        if len(opes_list) == 0:
            return

        g_opes = torch.cat(opes_list, dim=0)
        g_mas = torch.cat(mas_list, dim=0)
        g_obj = torch.cat(obj_list, dim=0)

        if self.global_pareto_archives["opes"] is not None:
            g_opes = torch.cat([self.global_pareto_archives["opes"], g_opes], dim=0)
            g_mas = torch.cat([self.global_pareto_archives["mas"], g_mas], dim=0)
            g_obj = torch.cat([self.global_pareto_archives["obj"], g_obj], dim=0)

        g_opes, g_mas, g_obj = self.unique_and_pareto(g_opes, g_mas, g_obj)

        self.global_pareto_archives = {
            "opes": g_opes,
            "mas": g_mas,
            "obj": g_obj
        }

    def unique_and_pareto(self, opes, mas, obj):
        opes, mas, obj = self.unique_archive(opes, mas, obj)
        opes, mas, obj = self.pareto_filter(opes, mas, obj)
        return opes, mas, obj

    def unique_archive(self, opes, mas, obj):
        unique = {}

        for i in range(opes.size(0)):
            key = (
                tuple(opes[i].tolist()),
                tuple(mas[i].tolist()),
                tuple(obj[i].tolist())
            )
            if key not in unique:
                unique[key] = i

        idx = torch.tensor(list(unique.values()), device=opes.device)
        return opes[idx], mas[idx], obj[idx]

    def pareto_filter(self, opes, mas, obj):
        if obj.size(0) <= 1:
            return opes, mas, obj

        a = obj.unsqueeze(1)
        b = obj.unsqueeze(0)

        dominates = (b <= a).all(-1) & (b < a).any(-1)
        dominated = dominates.any(0)

        keep = ~dominated
        return opes[keep], mas[keep], obj[keep]

    def calculate(self, omega_opes, omega_mas):

        # 1. 转化为Q(正交矩阵)
        Q_opes, Q_mas = self.A_to_Q(omega_opes, omega_mas)

        # 2. Get state and completion signal
        done = False
        star_action_time = time.time()
        while ~done:
            with torch.no_grad():
                jobs_action, mas_action, opes_action = self.action(Q_opes, Q_mas)
                dones = self.step(jobs_action, mas_action, opes_action)
            done = dones.all()
        action_time = time.time() - star_action_time
        makespans_batch = (self.makespan_batch.mean(dim=-1)).clone()
        energy_batch = (self.energy_batch.mean(dim=-1)).clone()
        daly_time_batch = (self.daly_time_batch.mean(dim=-1)).clone()
        objective = torch.stack([makespans_batch, energy_batch, daly_time_batch], dim=-1)
        print(f"---all_action_spend_time: {round(action_time, 4)}")

        gantt_result = self.validate_gantt()[0]
        if not gantt_result:
            print("Scheduling Error！！！！！！")

        return objective

    def reset_env(self, state):
        P = self.num_pop
        I = self.num_inds
        # 总工序数
        self.num_opes = state.num_opes
        # 每个算例的总工序数
        self.nums_opes = state.nums_opes
        # 工序-机器加工时间
        self.proc_times_batch = (state.proc_times_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 工序-机器加工状态
        self.ope_ma_adj_batch = (state.ope_ma_adj_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 工序属于第一个job,索引
        self.opes_appertain_batch = state.opes_appertain_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # 每个job开始工序索引
        self.str_ope_biases_batch = state.str_ope_biases_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # 每个job的工序总数
        self.nums_ope_batch = state.nums_ope_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # job的截止时间
        self.job_due_time_batch = state.job_due_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # job到达时间
        self.job_arrive_time_batch = state.job_arrive_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # 每个job结束工序索引
        self.end_ope_biases_batch = state.end_ope_biases_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # batch索引
        self.batch_idxes = (state.batch_idxes.to(self.device)).clone()
        # T_a调度时间
        self.time_batch = (state.time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 执行多少工序数量了
        self.N = (state.N.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 机器时间
        self.ma_time_batch = (state.ma_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 机器工作时间
        self.ma_work_time_batch = (state.ma_work_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 每个job上一工序的完工时间
        self.last_ope_comp_time_batch = (state.last_ope_comp_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 代加工的工序索引
        self.ope_step_batch = (state.ope_step_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录mas加工的job-id
        self.mask_mas_jobs_batch = (state.mask_mas_jobs_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 平均加工时间
        self.avg_proc_times_batch = (state.avg_proc_times_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 完成工序的平均加工时间
        self.comp_avg_proc_times_batch = (state.comp_avg_proc_times_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 利用平均时间估计job完工时间
        self.avg_end_time_batch = (state.avg_end_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 工序特征
        self.feat_opes_batch = (state.feat_opes_batch.to(self.device).to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 机器特征
        self.feat_mas_batch = (state.feat_mas_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 工序加工状态
        self.status_batch = (state.status_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # batch完工状态
        self.done_batch = (state.done_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 记录加工信息，验证
        self.schedules_batch = (state.schedules_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 记录job是否加工, True正在加工
        self.mask_job_procing_batch = (state.mask_job_procing_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录job是否完工, True完工
        self.mask_job_finish_batch = (state.mask_job_finish_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录mas是加工, True加工
        self.mask_ma_procing_batch = (state.mask_ma_procing_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 最大完工时间
        self.makespan_batch = (state.makespan_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 消耗电力能源
        self.energy_batch = (state.energy_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 延迟时间
        self.daly_time_batch = (state.daly_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 估算平均完工时间
        self.avg_end_time_batch = (state.avg_end_time_batch.to(self.device).unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录mas空闲时间的开始时间
        self.mas_star_times = torch.zeros(size=(self.num_pop, self.num_inds, self.batch_size, self.num_mas), device=self.device)

    def action(self, Q_opes, Q_mas):
        """
            Q_opes: num_pops*popsize*9*9    [P,I,9,9]
            Q_mas: num_pops*popsize*7*7    [P,I,7,7]
            self.feat_opes_batch: batch*9*num_jobs  [P,I,B,9,J]
            self.feat_opes_batch: batch*7*num_mas   [P,I,B,7,M]
        """
        # raw_opes.shape: [P,I,B,J,9], raw_mas.shape: [P,I,B,M,7]
        raw_opes = self.feat_opes_batch.transpose(-1, -2)
        raw_mas = self.feat_mas_batch.transpose(-1, -2)

        # [P,I,1,9,9]
        Q_opes_exp = Q_opes.unsqueeze(2)
        Q_mas_exp = Q_mas.unsqueeze(2)

        opes_score = torch.matmul(raw_opes, Q_opes_exp)
        opes_score = torch.sigmoid(opes_score) * opes_score

        mas_score = torch.matmul(raw_mas, Q_mas_exp)
        mas_score = torch.sigmoid(mas_score) * mas_score

        jobs_score = (opes_score ** 2).sum(dim=-1) / (opes_score.abs().sum(dim=-1) + 1e-8)
        mas_score = (mas_score ** 2).sum(dim=-1) / (mas_score.abs().sum(dim=-1) + 1e-8)

        # 可加工的job,mas
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        # proc_time_eligible = self.proc_times_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        # proc_time_eligible = proc_time_eligible*arrived_mask_exp
        eligible_proc_adj = self.ope_ma_adj_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        proc_adj_eligible = eligible_proc_adj * arrived_mask_exp
        ma_eligible = (~self.mask_ma_procing_batch.unsqueeze(-2)).expand_as(proc_adj_eligible)
        job_eligible = ((~self.mask_job_procing_batch) & (~self.mask_job_finish_batch) & (arrived_jobs_id)).unsqueeze(-1).expand_as(proc_adj_eligible)
        eligible = job_eligible & ma_eligible & (proc_adj_eligible == 1)

        j_eligible = eligible.sum(dim=-1).bool()
        jobs_score = jobs_score.masked_fill(~j_eligible, float('-inf'))
        jobs_action = jobs_score.argmax(dim=-1)

        job_index = jobs_action.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)
        selected_mas_eligible = torch.gather(eligible, dim=3, index=job_index)
        m_eligible = selected_mas_eligible.squeeze(3)
        mas_score = mas_score.masked_fill(~m_eligible, float('-inf'))
        mas_action = mas_score.argmax(dim=-1)

        opes_action = self.ope_step_batch.gather(-1, jobs_action.unsqueeze(-1)).squeeze(-1)

        # print(f"job:{jobs_action}")
        # print(f"mas:{mas_action}")
        # print(f"opes:{opes_action}")
        # print("\n")
        return jobs_action, mas_action, opes_action

    def cal_estimated_machine_cost(self, start_time, proc_time):
        """
        估计proc_time处理的电力成本从start_time开始。
        start_time: [B, M]
        proc_time:  [B, M]
        return:
            estimated_cost: [B, M]
        """
        proc_time = torch.clamp(proc_time, min=0.0)
        end_time = start_time + proc_time

        # 起始、结束小时
        h_start = torch.floor(start_time).long()
        h_end = torch.ceil(end_time).long()

        # 最多跨多少个小时
        K_max = max(int((h_end - h_start).max().item()), 1)
        k = torch.arange(K_max, device=start_time.device)

        # [B, M, K]
        abs_hour = h_start.unsqueeze(-1) + k
        abs_hour_float = abs_hour.to(start_time.dtype)


        # 每个小时与加工区间的交集
        left = torch.maximum(start_time.unsqueeze(-1), abs_hour_float)
        right = torch.minimum(end_time.unsqueeze(-1),abs_hour_float + 1.0)
        overlap = torch.clamp(right - left, min=0.0)

        # TOU 每24小时循环
        hour_idx = abs_hour % 24
        price_table = self.time_of_electric.to(start_time.device)
        price = price_table[hour_idx]

        # 求和
        tou_cost_time = torch.sum(overlap * price, dim=-1)
        # × 工作功率
        estimated_cost = tou_cost_time * self.work_power

        return estimated_cost

    def step(self, jobs_action, mas_action, opes_action):
        '''
            Environment transition function
        '''
        opes = opes_action
        mas = mas_action
        jobs = jobs_action

        P, I, B = opes.shape
        device = opes.device

        p_idx = torch.arange(P, device=device)[:, None, None]
        i_idx = torch.arange(I, device=device)[None, :, None]
        b_idx = torch.arange(B, device=device)[None, None, :]

        # Action_S_t,更新状态信息——>S_t+1
        self.mask_mas_jobs_batch[p_idx, i_idx, b_idx, mas] = jobs
        self.N += 1
        # 2. 改变ope_ma_adj_batch、proc_times_batch
        remain_ope_ma_adj = torch.zeros(size=(self.num_pop, self.num_inds, self.batch_size, self.num_mas), dtype=torch.int64)
        remain_ope_ma_adj[p_idx, i_idx, b_idx, mas] = 1
        self.ope_ma_adj_batch[p_idx, i_idx, b_idx, opes] = remain_ope_ma_adj[p_idx, i_idx, b_idx, :]
        self.proc_times_batch *= self.ope_ma_adj_batch

        # 记录加工状态
        self.ope_step_batch[p_idx, i_idx, b_idx, jobs] += 1
        self.mask_job_procing_batch[p_idx, i_idx, b_idx, jobs] = True
        self.mask_ma_procing_batch[p_idx, i_idx, b_idx, mas] = True
        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1, True, self.mask_job_finish_batch)
        self.done_batch = self.mask_job_finish_batch.all(dim=-1)

        # 计算工序的开始/结束时间
        # 计算, job到了，但没加工，确机床空, arrive < T_a
        opes_proc_times = self.proc_times_batch[p_idx, i_idx, b_idx, opes, mas]
        arrive_start = torch.max(self.job_arrive_time_batch[p_idx, i_idx, b_idx, jobs], self.last_ope_comp_time_batch[p_idx, i_idx, b_idx, jobs])
        opes_star_times = torch.max(self.ma_time_batch[p_idx, i_idx, b_idx, mas], arrive_start)
        opes_end_times = opes_star_times + opes_proc_times
        self.last_ope_comp_time_batch[p_idx, i_idx, b_idx, jobs] = opes_end_times
        self.ma_time_batch[p_idx, i_idx, b_idx, mas] = opes_end_times
        self.mas_star_times[p_idx, i_idx, b_idx, mas] = opes_end_times
        self.ma_work_time_batch[p_idx, i_idx, b_idx, mas] += opes_proc_times

        avg_opes_proc_times = self.avg_proc_times_batch[p_idx, i_idx, b_idx, opes]
        self.comp_avg_proc_times_batch[p_idx, i_idx, b_idx, jobs] += avg_opes_proc_times

        # 确定self.time调度时间点，检查当前是否具有可加工的工序
        flag_trans_2_next_time = self.if_no_eligible()
        while ~((~((flag_trans_2_next_time == 0) & (~self.done_batch))).all()):
            self.next_time(flag_trans_2_next_time)
            flag_trans_2_next_time = self.if_no_eligible()

        # 计算self.time调度时间点, 到达的job
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        proc_time_eligible = self.proc_times_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        # proc_time_eligible = proc_time_eligible*arrived_mask_exp

        eligible_proc_adj = self.ope_ma_adj_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        # proc_adj_eligible = eligible_proc_adj * arrived_mask_exp
        ma_eligible = ~self.mask_ma_procing_batch.unsqueeze(-2).expand_as(proc_time_eligible)
        job_eligible = (~(self.mask_job_procing_batch + self.mask_job_finish_batch)).unsqueeze(-1).expand_as(proc_time_eligible)
        eligible_time = torch.where(ma_eligible & job_eligible, proc_time_eligible.double(), 0.0)

        # 0. T_a 最小加工时间
        INF = torch.inf
        eligible_time_pos = eligible_time.clone()
        eligible_time_pos[eligible_time_pos <= 0] = INF
        min_proc_time, _ = eligible_time_pos.min(dim=-1)
        self.feat_opes_batch[:, :, :, 0, :] = min_proc_time * arrived_mask
        # 1. T_a 平均加工时间
        avg_opes_proc_time = torch.sum(eligible_time, dim=-1).div(torch.count_nonzero(eligible_time, dim=-1) + 1e-9)
        self.feat_opes_batch[:, :, :, 1, :] = avg_opes_proc_time * arrived_mask
        # 2. T_a最长加工时间
        max_proc_time, _ = eligible_time.max(dim=-1)
        self.feat_opes_batch[:, :, :, 2, :] = max_proc_time * arrived_mask
        # 3. T_a估计最大完工时间
        start_time_batch = torch.max(self.job_arrive_time_batch, self.last_ope_comp_time_batch)
        max_comp_time = start_time_batch + max_proc_time + (self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time)
        self.feat_opes_batch[:, :, :, 3, :] = max_comp_time * arrived_mask
        # 4. T_a估计剩余加工时间
        remain_proc_time = self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time
        self.feat_opes_batch[:, :, :, 4, :] = remain_proc_time * arrived_mask
        # 5. T_a等待加工时间
        pending_opes_time = self.time_batch.unsqueeze(-1).expand(-1, -1, -1, self.num_jobs) - torch.max(self.job_arrive_time_batch, self.last_ope_comp_time_batch)
        self.feat_opes_batch[:, :, :, 5, :] = pending_opes_time * arrived_mask
        # 6. T_a延迟时间
        daly_opes_time = max_comp_time - self.job_due_time_batch
        self.feat_opes_batch[:, :, :, 6, :] = daly_opes_time * arrived_mask
        # 7. T_a可加工的机器数
        num_opes_mas = torch.count_nonzero(eligible_time, dim=-1)
        self.feat_opes_batch[:, :, :, 7, :] = num_opes_mas * arrived_mask
        # 8. T_a剩余的工序数
        remain_opes_num = self.end_ope_biases_batch - ope_step_batch
        self.feat_opes_batch[:, :, :, 8, :] = remain_opes_num * arrived_mask

        # 0. T_a可加工的最小时间
        pending_eligible_time = eligible_time * arrived_mask.unsqueeze(-1)
        min_eligible_time_pos = pending_eligible_time.clone()
        min_eligible_time_pos[min_eligible_time_pos <= 0] = INF
        min_mas_time, _ = min_eligible_time_pos.min(dim=-2)
        valid_machine = torch.isfinite(min_mas_time)
        min_mas_time = torch.where(valid_machine, min_mas_time, torch.zeros_like(min_mas_time))
        self.feat_mas_batch[:, :, :, 0, :] = min_mas_time
        # 1. T_a可加工的平均时间
        avg_mas_proc_time = torch.sum(pending_eligible_time, dim=-2).div(torch.count_nonzero(pending_eligible_time, dim=-2) + 1e-9)
        self.feat_mas_batch[:, :, :, 1, :] = avg_mas_proc_time
        # 2. T_a可加工的最大时间
        max_mas_time, _ = torch.max(pending_eligible_time, dim=-2)
        self.feat_mas_batch[:, :, :, 2, :] = max_mas_time
        # 3. T_a可加工的工序数
        num_mas_opes = torch.count_nonzero(pending_eligible_time, dim=-2)
        self.feat_mas_batch[:, :, :, 3, :] = num_mas_opes
        # 4. T_a机器空闲时间
        free_mas_time = self.ma_time_batch - self.ma_work_time_batch
        self.feat_mas_batch[:, :, :, 4, :] = free_mas_time
        # 5. T_a机器负载
        self.feat_mas_batch[:, :, :, 5, :] = self.ma_work_time_batch
        # 6. 机器距离调度时间 = 0
        self.feat_mas_batch[:, :, :, 6, :] = self.time_batch.unsqueeze(-1).expand(-1, -1, -1, self.num_mas) - self.ma_time_batch
        # 7. 机器利用率
        utilization_rate = self.ma_work_time_batch.div(self.ma_time_batch)
        nan_mask = torch.isnan(utilization_rate)
        utilization_rate[nan_mask] = 0
        self.feat_mas_batch[:, :, :, 7, :] = utilization_rate
        # 8. 预计平均加工电费
        estimated_mas_cost = self.cal_estimated_machine_cost(
            self.ma_time_batch,
            avg_mas_proc_time.float()
        )
        self.feat_mas_batch[:, :, :, 8, :] = estimated_mas_cost

        # 计算目标值
        self.makespan_batch = torch.max(self.last_ope_comp_time_batch, dim=-1)[0]
        job_daly_time = torch.where((self.last_ope_comp_time_batch - self.job_due_time_batch) > 0, self.last_ope_comp_time_batch - self.job_due_time_batch, torch.tensor(0.))
        self.daly_time_batch = torch.sum(job_daly_time, dim=-1)
        # 工作时间按照opes, 计算分时定价
        h_start_opes = torch.floor(opes_star_times).long()
        h_end_opes = torch.ceil(opes_end_times).long()
        K_max_opes = (h_end_opes - h_start_opes).max().item()
        k_opes = torch.arange(K_max_opes, device=device)
        abs_hour_opes = h_start_opes.unsqueeze(-1) + k_opes
        left_opes = torch.maximum(opes_star_times.unsqueeze(-1), abs_hour_opes)
        right_opes = torch.minimum(opes_end_times.unsqueeze(-1), abs_hour_opes + 1)
        overlap_opes = torch.clamp(right_opes - left_opes, min=0.0)
        price_opes = self.time_of_electric[(abs_hour_opes % 24).long()]
        work_cost = torch.sum(overlap_opes * price_opes * self.work_power, dim=-1)

        # 空闲时间按照mas, 计算分时定价
        mas_end_times = self.time_batch.unsqueeze(-1).expand(-1, -1, -1, self.num_mas)
        mas_star_times = torch.where(self.ma_time_batch > mas_end_times, mas_end_times, self.mas_star_times)
        h_start_mas = torch.floor(mas_star_times).long()
        h_end_mas = torch.ceil(mas_end_times).long()
        K_max_mas = (h_end_mas - h_start_mas).max().item()
        k_mas = torch.arange(K_max_mas, device=device)
        abs_hour_mas = h_start_mas.unsqueeze(-1) + k_mas
        left_mas = torch.maximum(mas_star_times.unsqueeze(-1), abs_hour_mas)
        right_mas = torch.minimum(mas_end_times.unsqueeze(-1), abs_hour_mas + 1)
        overlap_mas = torch.clamp(right_mas - left_mas, min=0.0)
        pricea_mas = self.time_of_electric[(abs_hour_mas % 24).long()]
        unwork_cost = torch.sum(overlap_mas * pricea_mas * self.unwork_power, dim=-1).sum(-1)
        self.mas_star_times = torch.where(self.ma_time_batch > mas_end_times, self.ma_time_batch, mas_end_times)

        sum_cost = work_cost + unwork_cost
        self.energy_batch += sum_cost

        # self.object_dyn = torch.cat((self.makespan_batch.unsqueeze(1), self.energy_batch.unsqueeze(1), self.daly_time_batch.unsqueeze(1)), dim=1)
        # 用于验证
        self.schedules_batch[p_idx, i_idx, b_idx, opes, :2] = torch.stack((torch.ones(size=(self.num_pop, self.num_inds, self.batch_size)), mas), dim=-1)
        self.schedules_batch[p_idx, i_idx, b_idx, opes, 2] = opes_star_times
        self.schedules_batch[p_idx, i_idx, b_idx, opes, 3] = opes_end_times

        return self.done_batch

    def if_no_eligible(self):
        '''
        检查是否还有O-M对需要处理,Check if there are still O-M pairs to be processed
        '''
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        proc_time_eligible = self.proc_times_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        proc_time_eligible = proc_time_eligible*arrived_mask_exp

        ma_eligible = (~self.mask_ma_procing_batch.unsqueeze(-2)).expand_as(proc_time_eligible)
        job_eligible = ((~self.mask_job_procing_batch) & (~self.mask_job_finish_batch) & (arrived_jobs_id)).unsqueeze(-1).expand_as(proc_time_eligible)

        eligible_time = torch.where(ma_eligible & job_eligible, proc_time_eligible.double(), 0.0).transpose(-1, -2)
        flag_trans_2_next_time = torch.sum(eligible_time, dim=[-1, -2])

        return flag_trans_2_next_time

    def next_time(self, flag_trans_2_next_time):
        '''
        中转到下一次时间,Transit to the next time
        '''
        flag_need_trans = (flag_trans_2_next_time == 0) & (~self.done_batch)

        aa = self.ma_time_batch  # [P,I,B,M]

        # machine-driven next time
        INF = torch.inf
        max_time = torch.max(aa, dim=-1)[0] + 1.0
        bb = torch.where(aa > self.time_batch[..., None], aa, INF)
        next_machine_time = torch.min(bb, dim=-1)[0]

        # 判断是否存在 machine event
        has_machine_event = torch.isfinite(next_machine_time)
        # 设计调度时间点
        self.time_batch = torch.where(flag_need_trans & has_machine_event, next_machine_time, self.time_batch)
        # 设计调度时间点, self.time = max(mas_time), 没有可加工的工序, 就自+1
        self.time_batch = torch.where(flag_need_trans & (~has_machine_event), self.time_batch + 1.0, self.time_batch)

        # 在time下，self.ma_time <= self.time
        dd = (self.mask_ma_procing_batch & (self.ma_time_batch <= next_machine_time[..., None]) & flag_need_trans[..., None])
        pop_idx, ind_idx, batch_idx, mas_idx = torch.nonzero(dd, as_tuple=True)
        job_idx = self.mask_mas_jobs_batch[pop_idx, ind_idx, batch_idx, mas_idx]
        self.mask_job_procing_batch[pop_idx, ind_idx, batch_idx, job_idx] = False
        self.mask_ma_procing_batch[dd] = False

        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1, True, self.mask_job_finish_batch)

    def validate_gantt(self):
        '''
        Verify whether the schedule is feasible
        '''

        ma_gantt_batch = [ [[[[] for _ in range(self.num_mas)] for __ in range(self.batch_size)] for ___ in range(self.num_inds)] for ____ in range(self.num_pop)]
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                schedules_batch = self.schedules_batch[pop][ind]
                for batch_id, schedules in enumerate(schedules_batch):
                    for i in range(int(self.nums_opes[batch_id])):
                        step = schedules[i]
                        ma_gantt_batch[pop][ind][batch_id][int(step[1])].append([i, step[2].item(), step[3].item()])
        proc_time_batch = self.proc_times_batch

        # Check whether there are overlaps and correct processing times on the machine
        flag_proc_time = 0
        flag_ma_overlap = 0
        flag = 0
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                for b in range(self.batch_size):
                    ma_gantt = ma_gantt_batch[pop][ind][b]
                    proc_time = proc_time_batch[pop][ind][b]
                    for i in range(self.num_mas):
                        ma_gantt[i].sort(key=lambda s: s[1])
                        for j in range(len(ma_gantt[i])):
                            if (len(ma_gantt[i]) <= 1) or (j == len(ma_gantt[i]) - 1):
                                break
                            if ma_gantt[i][j][2] > ma_gantt[i][j + 1][1]:
                                flag_ma_overlap += 1
                            if ma_gantt[i][j][2] - ma_gantt[i][j][1] != proc_time[ma_gantt[i][j][0]][i]:
                                flag_proc_time += 1
                            flag += 1

        # Check job order and overlap
        flag_ope_overlap = 0
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                for k in range(self.batch_size):
                    schedule = self.schedules_batch[pop][ind][k]
                    nums_ope = self.nums_ope_batch[pop][ind][k]
                    num_ope_biases = self.str_ope_biases_batch[pop][ind][k]
                    for i in range(self.num_jobs):
                        if int(nums_ope[i]) <= 1:
                            continue
                        for j in range(int(nums_ope[i]) - 1):
                            step = schedule[num_ope_biases[i] + j]
                            step_next = schedule[num_ope_biases[i] + j + 1]
                            if step[3] > step_next[2]:
                                flag_ope_overlap += 1

        # Check whether there are unscheduled operations
        flag_unscheduled = 0
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                schedules_batch = self.schedules_batch[pop][ind]
                for batch_id, schedules in enumerate(schedules_batch):
                    count = 0
                    for i in range(schedules.size(0)):
                        if schedules[i][0] == 1:
                            count += 1
                    add = 0 if (count == self.nums_opes[batch_id]) else 1
                    flag_unscheduled += add

        if flag_ma_overlap + flag_ope_overlap + flag_proc_time + flag_unscheduled != 0:
            return False, self.schedules_batch
        else:
            return True, self.schedules_batch