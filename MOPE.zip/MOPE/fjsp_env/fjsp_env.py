import gym
import torch
from dataclasses import dataclass
from fjsp_env.load_data import load_fjs, nums_detec
import copy
import time

@dataclass
class EnvState:
    '''
        Class for the state of the environment
    '''
    batch_idxes: torch.Tensor = None
    feat_opes_batch: torch.Tensor = None
    feat_mas_batch: torch.Tensor = None
    proc_times_batch: torch.Tensor = None
    ope_ma_adj_batch: torch.Tensor = None
    mask_job_procing_batch: torch.Tensor = None
    mask_job_finish_batch: torch.Tensor = None
    mask_ma_procing_batch: torch.Tensor = None
    ope_step_batch: torch.Tensor = None

    end_ope_biases_batch: torch.Tensor = None
    job_arrive_time_batch: torch.Tensor = None
    time_batch: torch.Tensor = None
    makespan_batch: torch.Tensor = None
    energy_batch: torch.Tensor = None
    daly_time_batch: torch.Tensor = None

    def update(self,
               batch_idxes,
               feat_opes_batch,
               feat_mas_batch,
               proc_times_batch,
               ope_ma_adj_batch,
               mask_job_procing_batch,
               mask_job_finish_batch,
               mask_ma_procing_batch,
               ope_step_batch,
               end_ope_biases_batch,
               job_arrive_time_batch,
               time_batch,
               makespan_batch,
               daly_time_batch,
               energy_batch):
        self.batch_idxes = batch_idxes
        self.feat_opes_batch = feat_opes_batch
        self.feat_mas_batch = feat_mas_batch
        self.proc_times_batch = proc_times_batch
        self.ope_ma_adj_batch = ope_ma_adj_batch

        self.mask_job_procing_batch = mask_job_procing_batch
        self.mask_job_finish_batch = mask_job_finish_batch
        self.mask_ma_procing_batch = mask_ma_procing_batch

        self.ope_step_batch = ope_step_batch
        self.end_ope_biases_batch = end_ope_biases_batch
        self.job_arrive_time_batch = job_arrive_time_batch
        self.time_batch = time_batch

        self.makespan_batch = makespan_batch
        self.daly_time_batch = daly_time_batch
        self.energy_batch = energy_batch

@dataclass
class EAL_Env:
    '''
        Class for the state of the environment
    '''
    num_opes: int = None
    nums_opes: torch.Tensor = None
    proc_times_batch: torch.Tensor = None
    ope_ma_adj_batch: torch.Tensor = None
    opes_appertain_batch: torch.Tensor = None
    str_ope_biases_batch: torch.Tensor = None
    nums_ope_batch: torch.Tensor = None
    job_due_time_batch: torch.Tensor = None
    job_arrive_time_batch: torch.Tensor = None
    end_ope_biases_batch: torch.Tensor = None
    batch_idxes: torch.Tensor = None
    time_batch: torch.Tensor = None
    N: torch.Tensor = None
    ma_time_batch: torch.Tensor = None
    ma_work_time_batch: torch.Tensor = None
    last_ope_comp_time_batch: torch.Tensor = None
    ope_step_batch: torch.Tensor = None
    mask_mas_jobs_batch: torch.Tensor = None
    avg_proc_times_batch: torch.Tensor = None
    comp_avg_proc_times_batch: torch.Tensor = None
    feat_opes_batch: torch.Tensor = None
    feat_mas_batch: torch.Tensor = None
    status_batch: torch.Tensor = None
    done_batch: torch.Tensor = None
    schedules_batch: torch.Tensor = None
    mask_job_procing_batch: torch.Tensor = None
    mask_job_finish_batch: torch.Tensor = None
    mask_ma_procing_batch: torch.Tensor = None
    makespan_batch: torch.Tensor = None
    energy_batch: torch.Tensor = None
    daly_time_batch: torch.Tensor = None
    avg_end_time_batch: torch.Tensor = None

def convert_feat_job_2_ope(feat_job_batch, opes_appertain_batch):
    '''
    Convert job features into operation features (such as dimension)
    '''
    return feat_job_batch.gather(1, opes_appertain_batch)

class FJSPEnv(gym.Env):
    '''
        FJSP environment
    '''
    def __init__(self, case, env_paras, data_source):
        '''
            :param case: The instance generator or the addresses of the instances
            :param env_paras: A dictionary of parameters for the environment
            :param data_source: Indicates that the instances came from a generator or files
        '''
        self.flag_test = env_paras["flag_test"]
        self.batch_size = env_paras["batch_size"]  # Number of parallel instances during training
        self.num_jobs = env_paras["num_jobs"]  # Number of jobs
        self.num_mas = env_paras["num_mas"]  # Number of machines
        self.paras = env_paras  # Parameters
        self.device = env_paras["device"]  # Computing device for PyTorch
        self.work_power = env_paras["work_power"]
        self.unwork_power = env_paras["unwork_power"]
        time_of_electric = env_paras["time_of_electric"]
        self.time_of_electric = torch.tensor(
            time_of_electric,
            dtype=torch.float32,
            device=self.device
        )

        # load instance
        num_data = 8  # 从实例中提取的数据量,The amount of data extracted from instance
        tensors = [[] for _ in range(num_data)]
        self.num_opes = 0
        lines = []
        if data_source == 'case':  # Generate instances through generators
            for i in range(self.batch_size):
                lines.append(case.get_case(i)[0])  # Generate an instance and save it
                num_opes = nums_detec(lines[i])
                self.num_opes = max(self.num_opes, num_opes)
        else:  # Load instances from files
            for i in range(self.batch_size):
                with open(case[i]) as file_object:
                    line = file_object.readlines()
                    lines.append(line)
                num_opes = nums_detec(lines[i])
                self.num_opes = max(self.num_opes, num_opes)
        for i in range(self.batch_size):
            load_data = load_fjs(lines[i], self.num_mas, self.num_opes)
            for j in range(num_data):
                tensors[j].append(load_data[j])
        # dynamic feats
        # shape: (batch_size, num_opes, num_mas)，每个算例对应的job的加工时间
        self.proc_times_batch = torch.stack(tensors[0], dim=0)
        # 工序-机床的加工情况
        self.ope_ma_adj_batch = torch.stack(tensors[1], dim=0)
        # 工序属于那个job
        self.opes_appertain_batch = torch.stack(tensors[2], dim=0).long()
        # 每个job首工序id
        self.str_ope_biases_batch = torch.stack(tensors[3], dim=0).long()
        # 每个job的工序数
        self.nums_ope_batch = torch.stack(tensors[4], dim=0)
        # 计算矩阵
        self.cal_cumul_adj_batch = torch.stack(tensors[5], dim=0).float()
        # 截止时间
        self.job_due_time_batch = torch.stack(tensors[6], dim=0)
        self.ope_due_time_batch = self.job_due_time_batch.gather(1, self.opes_appertain_batch)
        # 到达时间
        self.job_arrive_time_batch = torch.stack(tensors[7], dim=0)
        # 每个job的结束工序id
        self.end_ope_biases_batch = self.str_ope_biases_batch + self.nums_ope_batch - 1
        # shape: (batch_size), the number of operations for each instance，每个算例的总工序数
        self.nums_opes = torch.sum(self.nums_ope_batch, dim=1)

        # dynamic variable
        self.batch_idxes = torch.arange(self.batch_size)    # range batch_size
        self.time_batch = torch.zeros(self.batch_size)            # 机床的最小的使用时间，Current time of the environment
        self.N = torch.zeros(self.batch_size).int()  # Count scheduled operations
        self.ma_time_batch = torch.zeros(size=(self.batch_size, self.num_mas))                 # 记录每个机床的时间
        self.ma_work_time_batch = torch.zeros(size=(self.batch_size, self.num_mas))   # 在当前机床的加工时间
        self.last_ope_comp_time_batch = torch.zeros(size=(self.batch_size, self.num_jobs))   # 记录每个工件已完成最后工序的完工时间
        self.ope_step_batch = copy.deepcopy(self.str_ope_biases_batch )         # 记录每个job 的开始工序
        self.mask_mas_jobs_batch = torch.zeros(size=(self.batch_size, self.num_mas)).long()     # 记录机床在加工的job
        self.avg_proc_times_batch = torch.sum(self.proc_times_batch, dim=2).div(torch.count_nonzero(self.ope_ma_adj_batch, dim=2) + 1e-9)
        self.comp_avg_proc_times_batch = torch.zeros(size=(self.batch_size, self.num_jobs))
        self.mas_star_times = torch.zeros(size=(self.batch_size, self.num_mas))

        # Masks of current status, dynamic
        # shape: (batch_size, num_jobs), True for jobs in process,
        self.mask_job_procing_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_jobs), True for completed jobs
        self.mask_job_finish_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_mas), True for machines in process
        self.mask_ma_procing_batch = torch.full(size=(self.batch_size, self.num_mas), dtype=torch.bool, fill_value=False)
        '''
            operations:
                0. 最短加工时间
                1. 平均加工时间
                2. 最长加工时间
                3. 估计完工时间
                4. 剩余加工时间
                5. 等待加工时间
                6. 延迟加工时间
                7. 可加工机器数
                8. 剩余加工数
            machines:
                0. 机器加工最小时间
                1. 机器加工平均时间
                2. 机器加工最大时间
                3. 可加工工序数
                4. 机器空闲时间
                5. 机器负载
                6. 机器距离调度时间
                7. 机器利用率
                8. 估计电费
        '''
        # Generate raw feature vectors
        feat_opes_batch = torch.zeros(size=(self.batch_size, self.paras["opes_feat_dim"], self.num_jobs))
        feat_mas_batch = torch.zeros(size=(self.batch_size, self.paras["mas_feat_dim"], self.num_mas))

        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(1)
        arrived_mask = arrived_jobs_id.float()

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        eligible_proc_adj = self.ope_ma_adj_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.proc_times_batch.size(2)))
        proc_time_eligible = self.proc_times_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.proc_times_batch.size(2)))
        ma_eligible = ~self.mask_ma_procing_batch.unsqueeze(1).expand_as(proc_time_eligible)
        job_eligible = ~(self.mask_job_procing_batch + self.mask_job_finish_batch)[:, :, None].expand_as(proc_time_eligible)
        eligible_time = torch.where(ma_eligible & job_eligible, proc_time_eligible.double(), 0.0)

        # 0. T_a 最小加工时间
        INF = torch.inf
        eligible_time_pos = eligible_time.clone()
        eligible_time_pos[eligible_time_pos <= 0] = INF
        min_proc_time, _ = eligible_time_pos.min(dim=2)
        feat_opes_batch[:, 0, :] = min_proc_time * arrived_mask
        # 1. T_a 平均加工时间
        avg_opes_proc_time = torch.sum(eligible_time, dim=2).div(torch.count_nonzero(eligible_time, dim=2) + 1e-9)
        feat_opes_batch[:, 1, :] = avg_opes_proc_time * arrived_mask
        # 2. T_a最长加工时间
        max_proc_time, _ = eligible_time.max(dim=2)
        feat_opes_batch[:, 2, :] = max_proc_time * arrived_mask
        # 3. T_a估计最大完工时间
        start_time_batch = torch.bmm(self.avg_proc_times_batch.unsqueeze(1), self.cal_cumul_adj_batch).squeeze()
        self.avg_end_time_batch = (start_time_batch + self.avg_proc_times_batch).gather(1, self.end_ope_biases_batch)
        max_comp_time = self.time_batch.unsqueeze(1).expand(-1, self.num_jobs) + max_proc_time + (self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time)
        feat_opes_batch[:, 3, :] = max_comp_time * arrived_mask
        # 4. T_a估计剩余加工时间
        remain_proc_time = self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time
        feat_opes_batch[:, 4, :] = remain_proc_time * arrived_mask
        # 5. T_a等待加工时间
        pending_opes_time = self.time_batch.unsqueeze(1).expand(-1, self.num_jobs) - torch.max(self.job_arrive_time_batch, self.last_ope_comp_time_batch)
        # pending_opes_time = torch.clamp(pending_opes_time, min=0.0)
        feat_opes_batch[:, 5, :] =  pending_opes_time * arrived_mask
        # 6. T_a延迟时间
        daly_opes_time = max_comp_time - self.job_due_time_batch
        feat_opes_batch[:, 6, :] = daly_opes_time * arrived_mask
        # 7. T_a可加工的机器数
        num_opes_mas = torch.count_nonzero(eligible_time, dim=2)
        feat_opes_batch[:, 7, :] = num_opes_mas * arrived_mask
        # 8. T_a剩余的工序数
        remain_opes_num = self.end_ope_biases_batch - ope_step_batch
        feat_opes_batch[:, 8, :] = remain_opes_num * arrived_mask

        # 0. T_a可加工的最小时间
        pending_eligible_time = eligible_time * arrived_mask.unsqueeze(-1)
        min_eligible_time_pos = pending_eligible_time.clone()
        min_eligible_time_pos[min_eligible_time_pos <= 0] = INF
        min_mas_time, _ = min_eligible_time_pos.min(dim=1)
        valid_machine = torch.isfinite(min_mas_time)
        min_mas_time = torch.where(valid_machine, min_mas_time, torch.zeros_like(min_mas_time))
        feat_mas_batch[:, 0, :] = min_mas_time
        # 1. T_a可加工的平均时间
        avg_mas_proc_time = torch.sum(pending_eligible_time, dim=1).div(torch.count_nonzero(pending_eligible_time, dim=1) + 1e-9)
        feat_mas_batch[:, 1, :] = avg_mas_proc_time
        # 2. T_a可加工的最大时间
        max_mas_time, _ = torch.max(pending_eligible_time, dim=1)
        feat_mas_batch[:, 2, :] = max_mas_time
        # 3. T_a可加工的工序数
        num_mas_opes = torch.count_nonzero(pending_eligible_time, dim=1)
        feat_mas_batch[:, 3, :] = num_mas_opes
        # 4. T_a机器空闲时间
        free_mas_time = self.ma_time_batch - self.ma_work_time_batch
        feat_mas_batch[:, 4, :] = free_mas_time
        # 5. T_a机器负载 = 0
        # 6. 机器距离调度时间 = 0、
        # 8. 预计平均加工电费
        estimated_mas_cost = self.cal_estimated_machine_cost(
            self.ma_time_batch,
            avg_mas_proc_time.float()
        )
        feat_mas_batch[:, 8, :] = estimated_mas_cost

        self.feat_opes_batch = feat_opes_batch
        self.feat_mas_batch = feat_mas_batch

        # 状态
        self.status_batch = torch.zeros(size=(self.batch_size, self.num_opes))
        self.done_batch = self.mask_job_finish_batch.all(dim=1)  # shape: (batch_size)
        self.schedules_batch = torch.zeros(size=(self.batch_size, self.num_opes, 4))    # 状态,mas,star_time,end_time

        # 目标
        self.makespan_batch = torch.zeros(self.batch_size)
        self.energy_batch = torch.zeros(self.batch_size)
        self.daly_time_batch = torch.zeros(self.batch_size)

        # 保存每个算例每小时的工作/空闲能耗
        max_proc_per_ope = self.proc_times_batch.max(dim=2).values
        max_proc_time = max_proc_per_ope.sum(dim=1)
        max_arrive_time = self.job_arrive_time_batch.max(dim=1).values
        self.max_time_slot = int(torch.ceil((max_arrive_time + max_proc_time).max()).item()) + 1
        self.hourly_work_energy_batch = torch.zeros(
            self.batch_size,
            self.max_time_slot,
            dtype=torch.float32,
            device=self.device
        )
        self.hourly_unwork_energy_batch = torch.zeros(
            self.batch_size,
            self.max_time_slot,
            dtype=torch.float32,
            device=self.device
        )

        # 保存解
        if self.flag_test:
            self.used_batch = torch.zeros(size=(self.batch_size, self.num_opes, 6)).int()  # job, ope, mas, proc_time, star_time, end_time
            self.ope_id = torch.zeros(size=(self.batch_size, self.num_jobs)).int()

        # Save initial data for reset
        self.old_feat_opes_batch = copy.deepcopy(self.feat_opes_batch)
        self.old_feat_mas_batch = copy.deepcopy(self.feat_mas_batch)
        self.old_proc_times_batch = copy.deepcopy(self.proc_times_batch)
        self.old_ope_ma_adj_batch = copy.deepcopy(self.ope_ma_adj_batch)
        self.old_avg_proc_times_batch = copy.deepcopy(self.avg_proc_times_batch)
        # self.old_state = copy.deepcopy(self.state)

    def cal_estimated_machine_cost(self, start_time, proc_time):
        """
        估计proc_time处理的电力成本从start_time开始。
        start_time: [B, M]
        proc_time:  [B, M]
        return:
            estimated_cost: [B, M]
        """
        proc_time = torch.clamp(proc_time, min=0.0)
        end_time = start_time + proc_time

        # 起始、结束小时
        h_start = torch.floor(start_time).long()
        h_end = torch.ceil(end_time).long()

        # 最多跨多少个小时
        K_max = max(int((h_end - h_start).max().item()), 1)
        k = torch.arange(K_max, device=start_time.device)

        # [B, M, K]
        abs_hour = h_start.unsqueeze(-1) + k
        abs_hour_float = abs_hour.to(start_time.dtype)

        # 每个小时与加工区间的交集
        left = torch.maximum(start_time.unsqueeze(-1), abs_hour_float)
        right = torch.minimum(end_time.unsqueeze(-1),abs_hour_float + 1.0)
        overlap = torch.clamp(right - left, min=0.0)

        # TOU 每24小时循环
        hour_idx = abs_hour % 24
        price_table = self.time_of_electric.to(start_time.device)
        price = price_table[hour_idx]

        # 求和
        tou_cost_time = torch.sum(overlap * price, dim=-1)
        # × 工作功率
        estimated_cost = tou_cost_time * self.work_power

        return estimated_cost

    def get_state(self):
        return EAL_Env(
            num_opes=self.num_opes,
            nums_opes=self.nums_opes.clone(),
            proc_times_batch=self.proc_times_batch.clone(),
            ope_ma_adj_batch=self.ope_ma_adj_batch.clone(),
            opes_appertain_batch=self.opes_appertain_batch.clone(),
            str_ope_biases_batch=self.str_ope_biases_batch.clone(),
            nums_ope_batch=self.nums_ope_batch.clone(),
            job_due_time_batch=self.job_due_time_batch.clone(),
            job_arrive_time_batch=self.job_arrive_time_batch.clone(),
            end_ope_biases_batch=self.end_ope_biases_batch.clone(),
            batch_idxes=self.batch_idxes.clone(),
            time_batch=self.time_batch.clone(),
            N=self.N.clone(),
            ma_time_batch=self.ma_time_batch.clone(),
            ma_work_time_batch=self.ma_work_time_batch.clone(),
            last_ope_comp_time_batch=self.last_ope_comp_time_batch.clone(),
            ope_step_batch=self.ope_step_batch.clone(),
            mask_mas_jobs_batch=self.mask_mas_jobs_batch.clone(),
            avg_proc_times_batch=self.avg_proc_times_batch.clone(),
            comp_avg_proc_times_batch=self.comp_avg_proc_times_batch.clone(),
            feat_opes_batch=self.feat_opes_batch.clone(),
            feat_mas_batch=self.feat_mas_batch.clone(),
            status_batch=self.status_batch.clone(),
            done_batch=self.done_batch.clone(),
            schedules_batch=self.schedules_batch.clone(),
            mask_job_procing_batch=self.mask_job_procing_batch.clone(),
            mask_job_finish_batch=self.mask_job_finish_batch.clone(),
            mask_ma_procing_batch=self.mask_ma_procing_batch.clone(),
            makespan_batch=self.makespan_batch.clone(),
            energy_batch = self.energy_batch.clone(),
            daly_time_batch=self.daly_time_batch.clone(),
            avg_end_time_batch=self.avg_end_time_batch.clone())

    def action(self, Q_opes, Q_mas):

        raw_opes = self.feat_opes_batch.transpose(1, 2)[self.batch_idxes]
        raw_mas = self.feat_mas_batch.transpose(1, 2)[self.batch_idxes]

        opes_score = torch.matmul(raw_opes, Q_opes)
        opes_score = torch.sigmoid(opes_score) * opes_score

        mas_score = torch.matmul(raw_mas, Q_mas)
        mas_score = torch.sigmoid(mas_score) * mas_score

        jobs_score = (opes_score ** 2).sum(dim=-1) / (opes_score.abs().sum(dim=-1) + 1e-8)
        mas_score = (mas_score ** 2).sum(dim=-1) / (mas_score.abs().sum(dim=-1) + 1e-8)

        # 可加工的job,mas
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        # proc_time_eligible = self.proc_times_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.num_mas))
        # proc_time_eligible = proc_time_eligible*arrived_mask_exp
        eligible_proc_adj = self.ope_ma_adj_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.num_mas))
        proc_adj_eligible = eligible_proc_adj * arrived_mask_exp
        ma_eligible = (~self.mask_ma_procing_batch.unsqueeze(-2)).expand_as(proc_adj_eligible)
        job_eligible = ((~self.mask_job_procing_batch) & (~self.mask_job_finish_batch) & (arrived_jobs_id)).unsqueeze(-1).expand_as(proc_adj_eligible)
        eligible = job_eligible & ma_eligible & (proc_adj_eligible == 1)

        if (~(eligible)).all():
            print("No eligible O-M pair!")
            return

        j_eligible = eligible.sum(dim=-1).bool()
        jobs_score = jobs_score.masked_fill(~j_eligible, float('-inf'))
        jobs_action = jobs_score.argmax(dim=-1)

        job_index = jobs_action.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, self.num_mas)
        selected_mas_eligible = torch.gather(eligible, dim=1, index=job_index)
        m_eligible = selected_mas_eligible.squeeze(1)
        mas_score = mas_score.masked_fill(~m_eligible, float('-inf'))
        mas_action = mas_score.argmax(dim=-1)

        opes_action = self.ope_step_batch.gather(-1, jobs_action.unsqueeze(-1)).squeeze(-1)

        return jobs_action, mas_action, opes_action

    def step(self, jobs_action, mas_action, opes_action):
        '''
        Environment transition function
        '''
        opes = opes_action
        mas = mas_action
        jobs = jobs_action

        # Action_S_t,更新状态信息——>S_t+1
        self.mask_mas_jobs_batch[self.batch_idxes, mas] = jobs
        self.N += 1
        # 2. 改变ope_ma_adj_batch、proc_times_batch
        remain_ope_ma_adj = torch.zeros(size=(self.batch_size, self.num_mas), dtype=torch.int64)
        remain_ope_ma_adj[self.batch_idxes, mas] = 1
        self.ope_ma_adj_batch[self.batch_idxes, opes] = remain_ope_ma_adj[self.batch_idxes, :]
        self.proc_times_batch *= self.ope_ma_adj_batch

        # 记录加工状态
        self.ope_step_batch[self.batch_idxes, jobs] += 1
        self.mask_job_procing_batch[self.batch_idxes, jobs] = True
        self.mask_ma_procing_batch[self.batch_idxes, mas] = True
        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1, True, self.mask_job_finish_batch)
        self.done_batch = self.mask_job_finish_batch.all(dim=-1)

        # 计算工序的开始/结束时间
        # 计算, job到了，但没加工，确机床空, arrive < T_a
        opes_proc_times = self.proc_times_batch[self.batch_idxes, opes, mas]
        arrive_start = torch.max(self.job_arrive_time_batch[self.batch_idxes, jobs], self.last_ope_comp_time_batch[self.batch_idxes, jobs])
        opes_star_times = torch.max(self.ma_time_batch[self.batch_idxes, mas], arrive_start)
        opes_end_times = opes_star_times + opes_proc_times
        self.last_ope_comp_time_batch[self.batch_idxes, jobs] = opes_end_times
        self.ma_time_batch[self.batch_idxes, mas] = opes_end_times
        self.mas_star_times[self.batch_idxes, mas] = opes_end_times
        self.ma_work_time_batch[self.batch_idxes, mas] += opes_proc_times

        avg_opes_proc_times = self.avg_proc_times_batch[self.batch_idxes, opes]
        self.comp_avg_proc_times_batch[self.batch_idxes, jobs] += avg_opes_proc_times

        # 确定self.time调度时间点，检查当前是否具有可加工的工序
        flag_trans_2_next_time = self.if_no_eligible()
        while ~((~((flag_trans_2_next_time == 0) & (~self.done_batch))).all()):
            self.next_time(flag_trans_2_next_time)
            flag_trans_2_next_time = self.if_no_eligible()

        # 计算self.time调度时间点, 到达的job
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        proc_time_eligible = self.proc_times_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.num_mas))
        # proc_time_eligible = proc_time_eligible*arrived_mask_exp

        eligible_proc_adj = self.ope_ma_adj_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.num_mas))
        # proc_adj_eligible = eligible_proc_adj * arrived_mask_exp
        ma_eligible = ~self.mask_ma_procing_batch.unsqueeze(-2).expand_as(proc_time_eligible)
        job_eligible = (~(self.mask_job_procing_batch + self.mask_job_finish_batch)).unsqueeze(-1).expand_as(proc_time_eligible)
        eligible_time = torch.where(ma_eligible & job_eligible, proc_time_eligible.double(), 0.0)

        # 0. T_a 最小加工时间
        INF = torch.inf
        eligible_time_pos = eligible_time.clone()
        eligible_time_pos[eligible_time_pos <= 0] = INF
        min_proc_time, _ = eligible_time_pos.min(dim=-1)
        self.feat_opes_batch[:, 0, :] = min_proc_time * arrived_mask
        # 1. T_a 平均加工时间
        avg_opes_proc_time = torch.sum(eligible_time, dim=-1).div(torch.count_nonzero(eligible_time, dim=-1) + 1e-9)
        self.feat_opes_batch[:, 1, :] = avg_opes_proc_time * arrived_mask
        # 2. T_a最长加工时间
        max_proc_time, _ = eligible_time.max(dim=-1)
        self.feat_opes_batch[:, 2, :] = max_proc_time * arrived_mask
        # 3. T_a估计最大完工时间
        start_time_batch = torch.max(self.job_arrive_time_batch, self.last_ope_comp_time_batch)
        max_comp_time = start_time_batch + max_proc_time + (self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time)
        self.feat_opes_batch[:, 3, :] = max_comp_time * arrived_mask
        # 4. T_a估计剩余加工时间
        remain_proc_time = self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time
        self.feat_opes_batch[:, 4, :] = remain_proc_time * arrived_mask
        # 5. T_a等待加工时间
        pending_opes_time = self.time_batch.unsqueeze(-1).expand(-1, self.num_jobs) - torch.max(self.job_arrive_time_batch, self.last_ope_comp_time_batch)
        self.feat_opes_batch[:, 5, :] = pending_opes_time * arrived_mask
        # 6. T_a延迟时间
        daly_opes_time = max_comp_time - self.job_due_time_batch
        self.feat_opes_batch[:, 6, :] = daly_opes_time * arrived_mask
        # 7. T_a可加工的机器数
        num_opes_mas = torch.count_nonzero(eligible_time, dim=-1)
        self.feat_opes_batch[:, 7, :] = num_opes_mas * arrived_mask
        # 8. T_a剩余的工序数
        remain_opes_num = self.end_ope_biases_batch - ope_step_batch
        self.feat_opes_batch[:, 8, :] = remain_opes_num * arrived_mask

        # 0. T_a可加工的最小时间
        pending_eligible_time = eligible_time * arrived_mask.unsqueeze(-1)
        min_eligible_time_pos = pending_eligible_time.clone()
        min_eligible_time_pos[min_eligible_time_pos <= 0] = INF
        min_mas_time, _ = min_eligible_time_pos.min(dim=1)
        valid_machine = torch.isfinite(min_mas_time)
        min_mas_time = torch.where(valid_machine, min_mas_time, torch.zeros_like(min_mas_time))
        self.feat_mas_batch[:, 0, :] = min_mas_time
        # 1. T_a可加工的平均时间
        avg_mas_proc_time = torch.sum(pending_eligible_time, dim=1).div(torch.count_nonzero(pending_eligible_time, dim=1) + 1e-9)
        self.feat_mas_batch[:, 1, :] = avg_mas_proc_time
        # 2. T_a可加工的最大时间
        max_mas_time, _ = torch.max(pending_eligible_time, dim=1)
        self.feat_mas_batch[:, 2, :] = max_mas_time
        # 3. T_a可加工的工序数
        num_mas_opes = torch.count_nonzero(pending_eligible_time, dim=1)
        self.feat_mas_batch[:, 3, :] = num_mas_opes
        # 4. T_a机器空闲时间
        free_mas_time = self.ma_time_batch - self.ma_work_time_batch
        self.feat_mas_batch[:, 4, :] = free_mas_time
        # 5. T_a机器负载
        self.feat_mas_batch[:, 5, :] = self.ma_work_time_batch
        # 6. 机器距离调度时间 = 0
        self.feat_mas_batch[:, 6, :] = self.time_batch.unsqueeze(-1).expand(-1, self.num_mas) - self.ma_time_batch
        # 7. 机器利用率
        utilization_rate = self.ma_work_time_batch.div(self.ma_time_batch)
        nan_mask = torch.isnan(utilization_rate)
        utilization_rate[nan_mask] = 0
        self.feat_mas_batch[:, 7, :] = utilization_rate
        # 8. 预计平均加工电费
        estimated_mas_cost = self.cal_estimated_machine_cost(
            self.ma_time_batch,
            avg_mas_proc_time.float())
        self.feat_mas_batch[:, 8, :] = estimated_mas_cost

        # 计算目标值
        self.makespan_batch = torch.max(self.last_ope_comp_time_batch, dim=-1)[0]
        job_daly_time = torch.where((self.last_ope_comp_time_batch - self.job_due_time_batch) > 0, self.last_ope_comp_time_batch - self.job_due_time_batch, torch.tensor(0.))
        self.daly_time_batch = torch.sum(job_daly_time, dim=-1)

        # 工作时间按照opes, 计算分时定价
        h_start_opes = torch.floor(opes_star_times).long()
        h_end_opes = torch.ceil(opes_end_times).long()
        K_max_opes = (h_end_opes - h_start_opes).max().item()
        k_opes = torch.arange(K_max_opes, device=self.device)
        abs_hour_opes = h_start_opes.unsqueeze(-1) + k_opes
        left_opes = torch.maximum(opes_star_times.unsqueeze(-1), abs_hour_opes)
        right_opes = torch.minimum(opes_end_times.unsqueeze(-1), abs_hour_opes + 1)
        overlap_opes = torch.clamp(right_opes - left_opes, min=0.0)

        work_energy_hourly = (overlap_opes * self.work_power)
        batch_ids = self.batch_idxes.to(self.device, dtype=torch.long)
        hour_ids = abs_hour_opes.clamp(min=0, max=self.max_time_slot - 1)
        flat_index = (batch_ids.unsqueeze(-1) * self.max_time_slot + hour_ids)
        self.hourly_work_energy_batch.view(-1).scatter_add_(0, flat_index.reshape(-1), work_energy_hourly.reshape(-1))

        price_opes = self.time_of_electric[(abs_hour_opes % 24).long()]
        work_cost = torch.sum(work_energy_hourly * price_opes, dim=-1)

        # 空闲时间按照mas, 计算分时定价
        mas_end_times = self.time_batch.unsqueeze(-1).expand(-1, self.num_mas)
        mas_star_times = torch.where(self.ma_time_batch > mas_end_times, mas_end_times, self.mas_star_times)
        h_start_mas = torch.floor(mas_star_times).long()
        h_end_mas = torch.ceil(mas_end_times).long()
        K_max_mas = (h_end_mas - h_start_mas).max().item()
        k_mas = torch.arange(K_max_mas, device=self.device)
        abs_hour_mas = h_start_mas.unsqueeze(-1) + k_mas
        left_mas = torch.maximum(mas_star_times.unsqueeze(-1), abs_hour_mas)
        right_mas = torch.minimum(mas_end_times.unsqueeze(-1), abs_hour_mas + 1)
        overlap_mas = torch.clamp(right_mas - left_mas, min=0.0)

        idle_energy_hourly = (overlap_mas * self.unwork_power)
        batch_ids = self.batch_idxes.to(self.device, dtype=torch.long)
        hour_ids = abs_hour_mas.clamp(min=0, max=self.max_time_slot - 1)
        batch_ids_expand = (batch_ids.view(-1, 1, 1).expand_as(hour_ids))
        flat_index = (batch_ids_expand * self.max_time_slot + hour_ids)
        self.hourly_unwork_energy_batch.view(-1).scatter_add_(0, flat_index.reshape(-1), idle_energy_hourly.reshape(-1))

        pricea_mas = self.time_of_electric[(abs_hour_mas % 24).long()]
        unwork_cost = torch.sum(overlap_mas * pricea_mas * self.unwork_power, dim=-1).sum(-1)
        self.mas_star_times = torch.where(self.ma_time_batch > mas_end_times, self.ma_time_batch, mas_end_times)

        sum_cost = work_cost + unwork_cost
        self.energy_batch += sum_cost
        self.objective_reward = self.makespan_batch + self.daly_time_batch + self.energy_batch

        # 用于验证
        self.schedules_batch[self.batch_idxes, opes, :2] = torch.stack((torch.ones(self.batch_idxes.size(0)), mas), dim=-1)
        self.schedules_batch[self.batch_idxes, opes, 2] = opes_star_times
        self.schedules_batch[self.batch_idxes, opes, 3] = opes_end_times

        if self.flag_test:
            # 10. 保存解
            self.used_batch[self.batch_idxes, (self.N - 1).long(), 0] = mas.int()
            self.used_batch[self.batch_idxes, (self.N-1).long(), 1] = jobs.int()
            self.used_batch[self.batch_idxes, (self.N-1).long(), 2] = self.ope_id[self.batch_idxes, jobs]
            self.used_batch[self.batch_idxes, (self.N-1).long(), 3] = opes_proc_times.int()
            self.used_batch[self.batch_idxes, (self.N-1).long(), 4] = opes_star_times.int()
            self.used_batch[self.batch_idxes, (self.N-1).long(), 5] = opes_end_times.int()
            self.ope_id[self.batch_idxes, jobs] += 1

        mask_finish = (self.N + 1) <= self.nums_opes
        if ~(mask_finish.all()):
            self.batch_idxes = torch.arange(self.batch_size)[mask_finish]

        return self.done_batch

    def if_no_eligible(self):
        '''
        检查是否还有O-M对需要处理,Check if there are still O-M pairs to be processed
        '''
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        proc_time_eligible = self.proc_times_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.num_mas))
        proc_time_eligible = proc_time_eligible * arrived_mask_exp

        ma_eligible = (~self.mask_ma_procing_batch.unsqueeze(-2)).expand_as(proc_time_eligible)
        job_eligible = ((~self.mask_job_procing_batch) & (~self.mask_job_finish_batch) & (arrived_jobs_id)).unsqueeze(-1).expand_as(proc_time_eligible)

        eligible_time = torch.where(ma_eligible & job_eligible, proc_time_eligible.double(), 0.0).transpose(-1, -2)
        flag_trans_2_next_time = torch.sum(eligible_time, dim=[-1, -2])

        return flag_trans_2_next_time

    def next_time(self, flag_trans_2_next_time):
        '''
        中转到下一次时间,Transit to the next time
        '''
        flag_need_trans = (flag_trans_2_next_time == 0) & (~self.done_batch)

        aa = self.ma_time_batch  # [P,I,B,M]

        # machine-driven next time
        INF = torch.inf
        max_time = torch.max(aa, dim=-1)[0] + 1.0
        bb = torch.where(aa > self.time_batch[..., None], aa, INF)
        next_machine_time = torch.min(bb, dim=-1)[0]

        # 判断是否存在 machine event
        has_machine_event = torch.isfinite(next_machine_time)
        # 设计调度时间点
        self.time_batch = torch.where(flag_need_trans & has_machine_event, next_machine_time, self.time_batch)
        # 设计调度时间点, self.time = max(mas_time), 没有可加工的工序, 就自+1
        self.time_batch = torch.where(flag_need_trans & (~has_machine_event), self.time_batch + 1.0, self.time_batch)

        # 在time下，self.ma_time <= self.time
        dd = (self.mask_ma_procing_batch & (self.ma_time_batch <= next_machine_time[..., None]) & flag_need_trans[..., None])
        batch_idx, mas_idx = torch.nonzero(dd, as_tuple=True)
        job_idx = self.mask_mas_jobs_batch[batch_idx, mas_idx]
        self.mask_job_procing_batch[batch_idx, job_idx] = False
        self.mask_ma_procing_batch[dd] = False

        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1, True, self.mask_job_finish_batch)

    def reset(self):
        '''
        将环境重置为初始状态Reset the environment to its initial state
        '''

        self.feat_opes_batch = copy.deepcopy(self.old_feat_opes_batch)
        self.feat_mas_batch = copy.deepcopy(self.old_feat_mas_batch)
        self.proc_times_batch = copy.deepcopy(self.old_proc_times_batch)
        self.ope_ma_adj_batch = copy.deepcopy(self.old_ope_ma_adj_batch)
        self.avg_proc_times_batch = copy.deepcopy(self.old_avg_proc_times_batch)

        self.batch_idxes = torch.arange(self.batch_size)
        self.time_batch = torch.zeros(self.batch_size)
        self.N = torch.zeros(self.batch_size).int()
        self.ma_time_batch = torch.zeros(size=(self.batch_size, self.num_mas))
        self.ma_work_time_batch = torch.zeros(size=(self.batch_size, self.num_mas))
        self.last_ope_comp_time_batch = torch.zeros(size=(self.batch_size, self.num_jobs))
        self.ope_step_batch = copy.deepcopy(self.str_ope_biases_batch )
        self.mask_mas_jobs_batch = torch.zeros(size=(self.batch_size, self.num_mas)).long()
        self.status_batch = torch.zeros(size=(self.batch_size, self.num_opes))
        self.mas_star_times = torch.zeros(size=(self.batch_size, self.num_mas))
        self.comp_avg_proc_times_batch = torch.zeros(size=(self.batch_size, self.num_jobs))

        # Masks of current status, dynamic
        self.mask_job_procing_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        self.mask_job_finish_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        self.mask_ma_procing_batch = torch.full(size=(self.batch_size, self.num_mas), dtype=torch.bool, fill_value=False)

        # 目标能耗
        self.makespan_batch = torch.zeros(self.batch_size)
        self.daly_time_batch = torch.zeros(self.batch_size)
        self.energy_batch = torch.zeros(self.batch_size)

        # 清空逐小时能源记录
        self.hourly_work_energy_batch.zero_()
        self.hourly_unwork_energy_batch.zero_()

        self.done_batch = self.mask_job_finish_batch.all(dim=1)  # shape: (batch_size)
        self.schedules_batch = torch.zeros(size=(self.batch_size, self.num_opes, 4))    # 状态,mas,star_time,end_time

        if self.flag_test:
            self.used_batch = torch.zeros(size=(self.batch_size, self.num_opes, 6)).int()
            self.ope_id = torch.zeros(size=(self.batch_size, self.num_jobs)).int()

    def validate_gantt(self):
        '''
        Verify whether the schedule is feasible
        '''
        ma_gantt_batch = [[[] for _ in range(self.num_mas)] for __ in range(self.batch_size)]
        for batch_id, schedules in enumerate(self.schedules_batch):
            for i in range(int(self.nums_opes[batch_id])):
                step = schedules[i]
                ma_gantt_batch[batch_id][int(step[1])].append([i, step[2].item(), step[3].item()])
        proc_time_batch = self.proc_times_batch

        # Check whether there are overlaps and correct processing times on the machine
        flag_proc_time = 0
        flag_ma_overlap = 0
        flag = 0
        for k in range(self.batch_size):
            ma_gantt = ma_gantt_batch[k]
            proc_time = proc_time_batch[k]
            for i in range(self.num_mas):
                ma_gantt[i].sort(key=lambda s: s[1])
                for j in range(len(ma_gantt[i])):
                    if (len(ma_gantt[i]) <= 1) or (j == len(ma_gantt[i]) - 1):
                        break
                    if ma_gantt[i][j][2] > ma_gantt[i][j + 1][1]:
                        flag_ma_overlap += 1
                    if ma_gantt[i][j][2] - ma_gantt[i][j][1] != proc_time[ma_gantt[i][j][0]][i]:
                        flag_proc_time += 1
                    flag += 1

        # Check job order and overlap
        flag_ope_overlap = 0
        for k in range(self.batch_size):
            schedule = self.schedules_batch[k]
            nums_ope = self.nums_ope_batch[k]
            num_ope_biases = self.str_ope_biases_batch[k]
            for i in range(self.num_jobs):
                if int(nums_ope[i]) <= 1:
                    continue
                for j in range(int(nums_ope[i]) - 1):
                    step = schedule[num_ope_biases[i] + j]
                    step_next = schedule[num_ope_biases[i] + j + 1]
                    if step[3] > step_next[2]:
                        flag_ope_overlap += 1

        # Check whether there are unscheduled operations
        flag_unscheduled = 0
        for batch_id, schedules in enumerate(self.schedules_batch):
            count = 0
            for i in range(schedules.size(0)):
                if schedules[i][0] == 1:
                    count += 1
            add = 0 if (count == self.nums_opes[batch_id]) else 1
            flag_unscheduled += add

        if flag_ma_overlap + flag_ope_overlap + flag_proc_time + flag_unscheduled != 0:
            return False, self.schedules_batch
        else:
            return True, self.schedules_batch

    def get_hourly_power_and_cost(self):
        """
            获取求解过程中已经按照原始目标函数记录的逐小时能源结果。
            Returns
            -------
            hourly_work_power : [B, H]
                每小时工作平均功率，单位 kW
            hourly_idle_power : [B, H]
                每小时空闲平均功率，单位 kW
            hourly_total_power : [B, H]
                每小时总平均功率，单位 kW
            hourly_price : [B, H]
                每小时 TOU 电价
            hourly_cost : [B, H]
                每小时能源成本
        """
        hourly_work_power = (self.hourly_work_energy_batch)

        hourly_idle_power = (self.hourly_unwork_energy_batch)

        hourly_total_power = (hourly_work_power + hourly_idle_power)

        # ---------------------------------------------------------
        # 24小时循环 TOU 电价
        # ---------------------------------------------------------
        hour_ids = torch.arange(self.max_time_slot, device=self.device)
        hourly_price = self.time_of_electric[hour_ids % 24]
        hourly_price = (hourly_price.unsqueeze(0).expand(self.batch_size, -1))

        # ---------------------------------------------------------
        # 每小时电费
        # ---------------------------------------------------------
        hourly_cost = (hourly_work_power + hourly_idle_power) * hourly_price

        return (
            hourly_work_power,
            hourly_idle_power,
            hourly_total_power,
            hourly_price,
            hourly_cost
        )
