from gym.envs.registration import register, registry, make, spec

env_id = 'fjsp-v0'

# Unregister the environment if it already exists
if env_id in registry.env_specs:
    del registry.env_specs[env_id]

register(
    id=env_id,  # Environment name (including version number)
    entry_point='fjsp_env.fjsp_env:FJSPEnv',  # The location of the environment class, like 'foldername.filename:classname'
)
