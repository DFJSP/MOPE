import gym
import fjsp_env
import torch
import time
import os
import copy

def get_validate_env(env_paras):
    '''
    读取测试算例
    '''

    ins_file_path = "./data/data_validate/{0}{1}/".format(env_paras["num_jobs"], str.zfill(str(env_paras["num_mas"]), 2))
    ins_data_files = os.listdir(ins_file_path)
    for i in range(len(ins_data_files)):
        ins_data_files[i] = ins_file_path + ins_data_files[i]
    case_ins = ins_data_files[0:env_paras["valid_batch_size"]]
    env = gym.make('fjsp-v0', case=case_ins, env_paras=env_paras, data_source='file')
    return env

class Valid():
    def __init__(self, paras):
        self.opes_feature_dim = paras["opes_feat_dim"]
        self.mas_feature_dim = paras["mas_feat_dim"]
        self.batch_size = paras["batch_size"]
        self.num_jobs = paras["num_jobs"]
        self.num_mas = paras["num_mas"]
        self.work_power = paras["work_power"]
        self.unwork_power = paras["unwork_power"]
        time_of_electric = paras["time_of_electric"]
        self.time_of_electric = torch.tensor(time_of_electric).float()

        self.num_pop = paras["num_pop"]
        self.num_inds = paras["num_individual"]

        # 记录验证的分数
        self.valid_score = []

    def reset_env(self, state):
        P = self.num_pop
        I = self.num_inds
        # 总工序数
        self.num_opes = state.num_opes
        # 每个算例的总工序数
        self.nums_opes = state.nums_opes
        # 工序-机器加工时间
        self.proc_times_batch = (state.proc_times_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 工序-机器加工状态
        self.ope_ma_adj_batch = (state.ope_ma_adj_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 工序属于第一个job,索引
        self.opes_appertain_batch = state.opes_appertain_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # 每个job开始工序索引
        self.str_ope_biases_batch = state.str_ope_biases_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # 每个job的工序总数
        self.nums_ope_batch = state.nums_ope_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # job的截止时间
        self.job_due_time_batch = state.job_due_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # job到达时间
        self.job_arrive_time_batch = state.job_arrive_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # 每个job结束工序索引
        self.end_ope_biases_batch = state.end_ope_biases_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)
        # batch索引
        self.batch_idxes = (state.batch_idxes).clone()
        # T_a调度时间
        self.time_batch = (state.time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 执行多少工序数量了
        self.N = (state.N.unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 机器时间
        self.ma_time_batch = (state.ma_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 机器工作时间
        self.ma_work_time_batch = (state.ma_work_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 每个job上一工序的完工时间
        self.last_ope_comp_time_batch = (state.last_ope_comp_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 代加工的工序索引
        self.ope_step_batch = (state.ope_step_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录mas加工的job-id
        self.mask_mas_jobs_batch = (state.mask_mas_jobs_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 平均加工时间
        self.avg_proc_times_batch = (state.avg_proc_times_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 完成工序的平均加工时间
        self.comp_avg_proc_times_batch = (state.comp_avg_proc_times_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 利用平均时间估计job完工时间
        self.avg_end_time_batch = (state.avg_end_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 工序特征
        self.feat_opes_batch = (state.feat_opes_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 机器特征
        self.feat_mas_batch = (state.feat_mas_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 工序加工状态
        self.status_batch = (state.status_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # batch完工状态
        self.done_batch = (state.done_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 记录加工信息，验证
        self.schedules_batch = (state.schedules_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1, -1)).clone()
        # 记录job是否加工, True正在加工
        self.mask_job_procing_batch = (state.mask_job_procing_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录job是否完工, True完工
        self.mask_job_finish_batch = (state.mask_job_finish_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录mas是加工, True加工
        self.mask_ma_procing_batch = (state.mask_ma_procing_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 最大完工时间
        self.makespan_batch = (state.makespan_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 消耗电力能源
        self.energy_batch = (state.energy_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 延迟时间
        self.daly_time_batch = (state.daly_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1)).clone()
        # 估算平均完工时间
        self.avg_end_time_batch = (state.avg_end_time_batch.unsqueeze(0).unsqueeze(0).expand(P, I, -1, -1)).clone()
        # 记录mas空闲时间的开始时间
        self.mas_star_times = torch.zeros(size=(self.num_pop, self.num_inds, self.batch_size, self.num_mas))


    def A_to_Q(self, omega_opes, omega_mas):
        A_opes = self.omega_to_A(omega_opes, self.opes_feature_dim)
        A_mas = self.omega_to_A(omega_mas, self.mas_feature_dim)

        Q_opes = torch.matrix_exp(A_opes)
        Q_mas = torch.matrix_exp(A_mas)

        return Q_opes, Q_mas

    def omega_to_A(self, omega, d):
        """
            omega: (..., D)
            return: (..., d, d)  skew-symmetric
        """
        *batch, D = omega.shape
        A = torch.zeros(*batch, d, d)

        idx = torch.triu_indices(d, d, offset=1)
        A[..., idx[0], idx[1]] = omega
        A[..., idx[1], idx[0]] = -omega
        return A

    def calculate(self, omega_opes, omega_mas):
        '''
        在培训期间验证策略，其过程类似于测试,Validate the policy during training, and the process is similar to test
        '''

        # 1. 转化为Q(正交矩阵)
        Q_opes, Q_mas = self.A_to_Q(omega_opes, omega_mas)

        print('There are {0} dev instances.'.format(self.batch_size))  # validation set is also called development set
        done = False
        valid_start = time.time()
        while ~done:
            with torch.no_grad():
                jobs_action, mas_action, opes_action = self.action(Q_opes, Q_mas)
                dones = self.step(jobs_action, mas_action, opes_action)
            done = dones.all()
        # gantt_result = self.validate_gantt()[0]
        # if not gantt_result:
        #     print("Scheduling Error！！！！！！")

        # 输出优解, 保存正交矩阵
        makespans_batch = (self.makespan_batch.mean(dim=-1)).clone()
        energy_batch = (self.energy_batch.mean(dim=-1)).clone()
        daly_time_batch = (self.daly_time_batch.mean(dim=-1)).clone()
        objective = torch.stack([makespans_batch, energy_batch, daly_time_batch], dim=-1)

        _value, _Q, _obj_ = self.get_Q(objective, Q_opes, Q_mas)

        print('validating time: ', time.time() - valid_start)

        return _value, _Q, _obj_

    def get_Q(self, objective, Q_opes, Q_mas):
        # 根据目标值pareto排序
        # [P, I, M]->[P, I, 1, M] (被比较者i 主)
        pop_obj_i = objective.unsqueeze(2)
        # [P, I, M]->[P, 1, I, M] (比较者j 副)
        pop_obj_j = objective.unsqueeze(1)
        # j <= i (逐目标)
        pop_less_equal = pop_obj_j <= pop_obj_i  # [P, I, I, M]
        # j < i (至少一个目标)
        pop_strictly_less = pop_obj_j < pop_obj_i  # [P, I, I, M]
        # True: j dominates i
        pop_dominates = pop_less_equal.all(dim=-1) & pop_strictly_less.any(dim=-1)
        # dominates[p, i, j] == True : j 支配 i
        # i 是否被任何 j 支配
        pop_dominated = pop_dominates.any(dim=-1)  # [P, I]
        # pop Pareto front
        pop_pareto_mask = ~pop_dominated

        # objective: [P, I, 3]
        INF = 1e10
        obj_sum = objective.sum(dim=-1)  # [P, I]
        masked_obj_sum = obj_sum.clone()
        masked_obj_sum[~pop_pareto_mask] = INF  # 只保留前沿

        global_best_value, global_best_flat_index = masked_obj_sum.view(-1).min(dim=0)
        _p = global_best_flat_index // self.num_inds
        _i = global_best_flat_index % self.num_inds

        _Q_opes = Q_opes[_p][_i]
        _Q_mas = Q_mas[_p][_i]
        _obj = objective[_p][_i]
        _obj_ = torch.cat([_obj, global_best_value.unsqueeze(0)])

        self.valid_score.append(_obj_)

        return global_best_value, (_Q_opes, _Q_mas), self.valid_score

    def action(self, Q_opes, Q_mas):
        """
            Q_opes: num_pops*popsize*9*9    [P,I,9,9]
            Q_mas: num_pops*popsize*7*7    [P,I,7,7]
            self.feat_opes_batch: batch*9*num_jobs  [P,I,B,9,J]
            self.feat_opes_batch: batch*7*num_mas   [P,I,B,7,M]
        """
        # raw_opes.shape: [P,I,B,J,9], raw_mas.shape: [P,I,B,M,7]
        raw_opes = self.feat_opes_batch.transpose(-1, -2)
        raw_mas = self.feat_mas_batch.transpose(-1, -2)

        # [P,I,1,9,9]
        Q_opes_exp = Q_opes.unsqueeze(2)
        Q_mas_exp = Q_mas.unsqueeze(2)

        opes_score = torch.matmul(raw_opes, Q_opes_exp)
        opes_score = torch.sigmoid(opes_score) * opes_score

        mas_score = torch.matmul(raw_mas, Q_mas_exp)
        mas_score = torch.sigmoid(mas_score) * mas_score

        jobs_score = (opes_score ** 2).sum(dim=-1) / (opes_score.abs().sum(dim=-1) + 1e-8)
        mas_score = (mas_score ** 2).sum(dim=-1) / (mas_score.abs().sum(dim=-1) + 1e-8)

        # 可加工的job,mas
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch,
                                     self.ope_step_batch)
        # proc_time_eligible = self.proc_times_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        # proc_time_eligible = proc_time_eligible*arrived_mask_exp
        eligible_proc_adj = self.ope_ma_adj_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1,
                                                                                                self.num_mas))
        proc_adj_eligible = eligible_proc_adj * arrived_mask_exp
        ma_eligible = (~self.mask_ma_procing_batch.unsqueeze(-2)).expand_as(proc_adj_eligible)
        job_eligible = ((~self.mask_job_procing_batch) & (~self.mask_job_finish_batch) & (arrived_jobs_id)).unsqueeze(
            -1).expand_as(proc_adj_eligible)
        eligible = job_eligible & ma_eligible & (proc_adj_eligible == 1)

        j_eligible = eligible.sum(dim=-1).bool()
        jobs_score = jobs_score.masked_fill(~j_eligible, float('-inf'))
        jobs_action = jobs_score.argmax(dim=-1)

        job_index = jobs_action.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)
        selected_mas_eligible = torch.gather(eligible, dim=3, index=job_index)
        m_eligible = selected_mas_eligible.squeeze(3)
        mas_score = mas_score.masked_fill(~m_eligible, float('-inf'))
        mas_action = mas_score.argmax(dim=-1)

        opes_action = self.ope_step_batch.gather(-1, jobs_action.unsqueeze(-1)).squeeze(-1)

        return jobs_action, mas_action, opes_action

    def cal_estimated_machine_cost(self, start_time, proc_time):
        """
        估计proc_time处理的电力成本从start_time开始。
        start_time: [B, M]
        proc_time:  [B, M]
        return:
            estimated_cost: [B, M]
        """
        proc_time = torch.clamp(proc_time, min=0.0)
        end_time = start_time + proc_time

        # 起始、结束小时
        h_start = torch.floor(start_time).long()
        h_end = torch.ceil(end_time).long()

        # 最多跨多少个小时
        K_max = max(int((h_end - h_start).max().item()), 1)
        k = torch.arange(K_max, device=start_time.device)

        # [B, M, K]
        abs_hour = h_start.unsqueeze(-1) + k
        abs_hour_float = abs_hour.to(start_time.dtype)

        # 每个小时与加工区间的交集
        left = torch.maximum(start_time.unsqueeze(-1), abs_hour_float)
        right = torch.minimum(end_time.unsqueeze(-1),abs_hour_float + 1.0)
        overlap = torch.clamp(right - left, min=0.0)

        # TOU 每24小时循环
        hour_idx = abs_hour % 24
        price_table = self.time_of_electric.to(start_time.device)
        price = price_table[hour_idx]

        # 求和
        tou_cost_time = torch.sum(overlap * price, dim=-1)
        # × 工作功率
        estimated_cost = tou_cost_time * self.work_power

        return estimated_cost

    def step(self, jobs_action, mas_action, opes_action):
        '''
            Environment transition function
        '''
        opes = opes_action
        mas = mas_action
        jobs = jobs_action

        P, I, B = opes.shape
        device = opes.device

        p_idx = torch.arange(P, device=device)[:, None, None]
        i_idx = torch.arange(I, device=device)[None, :, None]
        b_idx = torch.arange(B, device=device)[None, None, :]

        # Action_S_t,更新状态信息——>S_t+1
        self.mask_mas_jobs_batch[p_idx, i_idx, b_idx, mas] = jobs
        self.N += 1
        # 2. 改变ope_ma_adj_batch、proc_times_batch
        remain_ope_ma_adj = torch.zeros(size=(self.num_pop, self.num_inds, self.batch_size, self.num_mas), dtype=torch.int64)
        remain_ope_ma_adj[p_idx, i_idx, b_idx, mas] = 1
        self.ope_ma_adj_batch[p_idx, i_idx, b_idx, opes] = remain_ope_ma_adj[p_idx, i_idx, b_idx, :]
        self.proc_times_batch *= self.ope_ma_adj_batch

        # 记录加工状态
        self.ope_step_batch[p_idx, i_idx, b_idx, jobs] += 1
        self.mask_job_procing_batch[p_idx, i_idx, b_idx, jobs] = True
        self.mask_ma_procing_batch[p_idx, i_idx, b_idx, mas] = True
        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1, True, self.mask_job_finish_batch)
        self.done_batch = self.mask_job_finish_batch.all(dim=-1)

        # 计算工序的开始/结束时间
        # 计算, job到了，但没加工，确机床空, arrive < T_a
        opes_proc_times = self.proc_times_batch[p_idx, i_idx, b_idx, opes, mas]
        arrive_start = torch.max(self.job_arrive_time_batch[p_idx, i_idx, b_idx, jobs], self.last_ope_comp_time_batch[p_idx, i_idx, b_idx, jobs])
        opes_star_times = torch.max(self.ma_time_batch[p_idx, i_idx, b_idx, mas], arrive_start)
        opes_end_times = opes_star_times + opes_proc_times
        self.last_ope_comp_time_batch[p_idx, i_idx, b_idx, jobs] = opes_end_times
        self.ma_time_batch[p_idx, i_idx, b_idx, mas] = opes_end_times
        self.mas_star_times[p_idx, i_idx, b_idx, mas] = opes_end_times
        self.ma_work_time_batch[p_idx, i_idx, b_idx, mas] += opes_proc_times

        avg_opes_proc_times = self.avg_proc_times_batch[p_idx, i_idx, b_idx, opes]
        self.comp_avg_proc_times_batch[p_idx, i_idx, b_idx, jobs] += avg_opes_proc_times

        # 确定self.time调度时间点，检查当前是否具有可加工的工序
        flag_trans_2_next_time = self.if_no_eligible()
        while ~((~((flag_trans_2_next_time == 0) & (~self.done_batch))).all()):
            self.next_time(flag_trans_2_next_time)
            flag_trans_2_next_time = self.if_no_eligible()

        # 计算self.time调度时间点, 到达的job
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        proc_time_eligible = self.proc_times_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        # proc_time_eligible = proc_time_eligible*arrived_mask_exp

        eligible_proc_adj = self.ope_ma_adj_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        # proc_adj_eligible = eligible_proc_adj * arrived_mask_exp
        ma_eligible = ~self.mask_ma_procing_batch.unsqueeze(-2).expand_as(proc_time_eligible)
        job_eligible = (~(self.mask_job_procing_batch + self.mask_job_finish_batch)).unsqueeze(-1).expand_as(proc_time_eligible)
        eligible_time = torch.where(ma_eligible & job_eligible, proc_time_eligible.double(), 0.0)

        # 0. T_a 最小加工时间
        INF = torch.inf
        eligible_time_pos = eligible_time.clone()
        eligible_time_pos[eligible_time_pos <= 0] = INF
        min_proc_time, _ = eligible_time_pos.min(dim=-1)
        self.feat_opes_batch[:, :, :, 0, :] = min_proc_time * arrived_mask
        # 1. T_a 平均加工时间
        avg_opes_proc_time = torch.sum(eligible_time, dim=-1).div(torch.count_nonzero(eligible_time, dim=-1) + 1e-9)
        self.feat_opes_batch[:, :, :, 1, :] = avg_opes_proc_time * arrived_mask
        # 2. T_a最长加工时间
        max_proc_time, _ = eligible_time.max(dim=-1)
        self.feat_opes_batch[:, :, :, 2, :] = max_proc_time * arrived_mask
        # 3. T_a估计最大完工时间
        start_time_batch = torch.max(self.job_arrive_time_batch, self.last_ope_comp_time_batch)
        max_comp_time = start_time_batch + max_proc_time + (self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time)
        self.feat_opes_batch[:, :, :, 3, :] = max_comp_time * arrived_mask
        # 4. T_a估计剩余加工时间
        remain_proc_time = self.avg_end_time_batch - self.comp_avg_proc_times_batch - avg_opes_proc_time
        self.feat_opes_batch[:, :, :, 4, :] = remain_proc_time * arrived_mask
        # 5. T_a等待加工时间
        pending_opes_time = self.time_batch.unsqueeze(-1).expand(-1, -1, -1, self.num_jobs) - torch.max(self.job_arrive_time_batch, self.last_ope_comp_time_batch)
        self.feat_opes_batch[:, :, :, 5, :] = pending_opes_time * arrived_mask
        # 6. T_a延迟时间
        daly_opes_time = max_comp_time - self.job_due_time_batch
        self.feat_opes_batch[:, :, :, 6, :] = daly_opes_time * arrived_mask
        # 7. T_a可加工的机器数
        num_opes_mas = torch.count_nonzero(eligible_time, dim=-1)
        self.feat_opes_batch[:, :, :, 7, :] = num_opes_mas * arrived_mask
        # 8. T_a剩余的工序数
        remain_opes_num = self.end_ope_biases_batch - ope_step_batch
        self.feat_opes_batch[:, :, :, 8, :] = remain_opes_num * arrived_mask

        # 0. T_a可加工的最小时间
        pending_eligible_time = eligible_time * arrived_mask.unsqueeze(-1)
        min_eligible_time_pos = pending_eligible_time.clone()
        min_eligible_time_pos[min_eligible_time_pos <= 0] = INF
        min_mas_time, _ = min_eligible_time_pos.min(dim=-2)
        valid_machine = torch.isfinite(min_mas_time)
        min_mas_time = torch.where(valid_machine, min_mas_time, torch.zeros_like(min_mas_time))
        self.feat_mas_batch[:, :, :, 0, :] = min_mas_time
        # 1. T_a可加工的平均时间
        avg_mas_proc_time = torch.sum(pending_eligible_time, dim=-2).div(torch.count_nonzero(pending_eligible_time, dim=-2) + 1e-9)
        self.feat_mas_batch[:, :, :, 1, :] = avg_mas_proc_time
        # 2. T_a可加工的最大时间
        max_mas_time, _ = torch.max(pending_eligible_time, dim=-2)
        self.feat_mas_batch[:, :, :, 2, :] = max_mas_time
        # 3. T_a可加工的工序数
        num_mas_opes = torch.count_nonzero(pending_eligible_time, dim=-2)
        self.feat_mas_batch[:, :, :, 3, :] = num_mas_opes
        # 4. T_a机器空闲时间
        free_mas_time = self.ma_time_batch - self.ma_work_time_batch
        self.feat_mas_batch[:, :, :, 4, :] = free_mas_time
        # 5. T_a机器负载
        self.feat_mas_batch[:, :, :, 5, :] = self.ma_work_time_batch
        # 6. 机器距离调度时间 = 0
        self.feat_mas_batch[:, :, :, 6, :] = self.time_batch.unsqueeze(-1).expand(-1, -1, -1, self.num_mas) - self.ma_time_batch
        # 7. 机器利用率
        utilization_rate = self.ma_work_time_batch.div(self.ma_time_batch)
        nan_mask = torch.isnan(utilization_rate)
        utilization_rate[nan_mask] = 0
        self.feat_mas_batch[:, :, :, 7, :] = utilization_rate
        # 8. 预计平均加工电费
        estimated_mas_cost = self.cal_estimated_machine_cost(
            self.ma_time_batch,
            avg_mas_proc_time.float())
        self.feat_mas_batch[:, :, :, 8, :] = estimated_mas_cost

        # 计算目标值
        self.makespan_batch = torch.max(self.last_ope_comp_time_batch, dim=-1)[0]
        job_daly_time = torch.where((self.last_ope_comp_time_batch - self.job_due_time_batch) > 0, self.last_ope_comp_time_batch - self.job_due_time_batch, torch.tensor(0.))
        self.daly_time_batch = torch.sum(job_daly_time, dim=-1)
        # 工作时间按照opes, 计算分时定价
        h_start_opes = torch.floor(opes_star_times).long()
        h_end_opes = torch.ceil(opes_end_times).long()
        K_max_opes = (h_end_opes - h_start_opes).max().item()
        k_opes = torch.arange(K_max_opes, device=device)
        abs_hour_opes = h_start_opes.unsqueeze(-1) + k_opes
        left_opes = torch.maximum(opes_star_times.unsqueeze(-1), abs_hour_opes)
        right_opes = torch.minimum(opes_end_times.unsqueeze(-1), abs_hour_opes + 1)
        overlap_opes = torch.clamp(right_opes - left_opes, min=0.0)
        price_opes = self.time_of_electric[(abs_hour_opes % 24).long()]
        work_cost = torch.sum(overlap_opes * price_opes * self.work_power, dim=-1)

        # 空闲时间按照mas, 计算分时定价
        mas_end_times = self.time_batch.unsqueeze(-1).expand(-1, -1, -1, self.num_mas)
        mas_star_times = torch.where(self.ma_time_batch > mas_end_times, mas_end_times, self.mas_star_times)
        h_start_mas = torch.floor(mas_star_times).long()
        h_end_mas = torch.ceil(mas_end_times).long()
        K_max_mas = (h_end_mas - h_start_mas).max().item()
        k_mas = torch.arange(K_max_mas, device=device)
        abs_hour_mas = h_start_mas.unsqueeze(-1) + k_mas
        left_mas = torch.maximum(mas_star_times.unsqueeze(-1), abs_hour_mas)
        right_mas = torch.minimum(mas_end_times.unsqueeze(-1), abs_hour_mas + 1)
        overlap_mas = torch.clamp(right_mas - left_mas, min=0.0)
        pricea_mas = self.time_of_electric[(abs_hour_mas % 24).long()]
        unwork_cost = torch.sum(overlap_mas * pricea_mas * self.unwork_power, dim=-1).sum(-1)
        self.mas_star_times = torch.where(self.ma_time_batch > mas_end_times, self.ma_time_batch, mas_end_times)

        sum_cost = work_cost + unwork_cost
        self.energy_batch += sum_cost

        # self.object_dyn = torch.cat((self.makespan_batch.unsqueeze(1), self.energy_batch.unsqueeze(1), self.daly_time_batch.unsqueeze(1)), dim=1)
        # 用于验证
        self.schedules_batch[p_idx, i_idx, b_idx, opes, :2] = torch.stack((torch.ones(size=(self.num_pop, self.num_inds, self.batch_size)), mas), dim=-1)
        self.schedules_batch[p_idx, i_idx, b_idx, opes, 2] = opes_star_times
        self.schedules_batch[p_idx, i_idx, b_idx, opes, 3] = opes_end_times

        return self.done_batch

    def if_no_eligible(self):
        '''
        检查是否还有O-M对需要处理,Check if there are still O-M pairs to be processed
        '''
        arrived_jobs_id = self.job_arrive_time_batch <= self.time_batch.unsqueeze(-1)
        arrived_mask = arrived_jobs_id.float()
        arrived_mask_exp = arrived_mask.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)
        proc_time_eligible = self.proc_times_batch.gather(3, ope_step_batch.unsqueeze(-1).expand(-1, -1, -1, -1, self.num_mas))
        proc_time_eligible = proc_time_eligible*arrived_mask_exp

        ma_eligible = (~self.mask_ma_procing_batch.unsqueeze(-2)).expand_as(proc_time_eligible)
        job_eligible = ((~self.mask_job_procing_batch) & (~self.mask_job_finish_batch) & (arrived_jobs_id)).unsqueeze(-1).expand_as(proc_time_eligible)

        eligible_time = torch.where(ma_eligible & job_eligible, proc_time_eligible.double(), 0.0).transpose(-1, -2)
        flag_trans_2_next_time = torch.sum(eligible_time, dim=[-1, -2])

        return flag_trans_2_next_time

    def next_time(self, flag_trans_2_next_time):
        '''
        中转到下一次时间,Transit to the next time
        '''
        flag_need_trans = (flag_trans_2_next_time == 0) & (~self.done_batch)

        aa = self.ma_time_batch  # [P,I,B,M]

        # machine-driven next time
        INF = torch.inf
        max_time = torch.max(aa, dim=-1)[0] + 1.0
        bb = torch.where(aa > self.time_batch[..., None], aa, INF)
        next_machine_time = torch.min(bb, dim=-1)[0]

        # 判断是否存在 machine event
        has_machine_event = torch.isfinite(next_machine_time)
        # 设计调度时间点
        self.time_batch = torch.where(flag_need_trans & has_machine_event, next_machine_time, self.time_batch)
        # 设计调度时间点, self.time = max(mas_time), 没有可加工的工序, 就自+1
        self.time_batch = torch.where(flag_need_trans & (~has_machine_event), self.time_batch + 1.0, self.time_batch)

        # 在time下，self.ma_time <= self.time
        dd = (self.mask_ma_procing_batch & (self.ma_time_batch <= next_machine_time[..., None]) & flag_need_trans[..., None])
        pop_idx, ind_idx, batch_idx, mas_idx = torch.nonzero(dd, as_tuple=True)
        job_idx = self.mask_mas_jobs_batch[pop_idx, ind_idx, batch_idx, mas_idx]
        self.mask_job_procing_batch[pop_idx, ind_idx, batch_idx, job_idx] = False
        self.mask_ma_procing_batch[dd] = False

        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1, True, self.mask_job_finish_batch)

    def validate_gantt(self):
        '''
        Verify whether the schedule is feasible
        '''

        ma_gantt_batch = [ [[[[] for _ in range(self.num_mas)] for __ in range(self.batch_size)] for ___ in range(self.num_inds)] for ____ in range(self.num_pop)]
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                schedules_batch = self.schedules_batch[pop][ind]
                for batch_id, schedules in enumerate(schedules_batch):
                    for i in range(int(self.nums_opes[batch_id])):
                        step = schedules[i]
                        ma_gantt_batch[pop][ind][batch_id][int(step[1])].append([i, step[2].item(), step[3].item()])
        proc_time_batch = self.proc_times_batch

        # Check whether there are overlaps and correct processing times on the machine
        flag_proc_time = 0
        flag_ma_overlap = 0
        flag = 0
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                for b in range(self.batch_size):
                    ma_gantt = ma_gantt_batch[pop][ind][b]
                    proc_time = proc_time_batch[pop][ind][b]
                    for i in range(self.num_mas):
                        ma_gantt[i].sort(key=lambda s: s[1])
                        for j in range(len(ma_gantt[i])):
                            if (len(ma_gantt[i]) <= 1) or (j == len(ma_gantt[i]) - 1):
                                break
                            if ma_gantt[i][j][2] > ma_gantt[i][j + 1][1]:
                                flag_ma_overlap += 1
                            if ma_gantt[i][j][2] - ma_gantt[i][j][1] != proc_time[ma_gantt[i][j][0]][i]:
                                flag_proc_time += 1
                            flag += 1

        # Check job order and overlap
        flag_ope_overlap = 0
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                for k in range(self.batch_size):
                    schedule = self.schedules_batch[pop][ind][k]
                    nums_ope = self.nums_ope_batch[pop][ind][k]
                    num_ope_biases = self.str_ope_biases_batch[pop][ind][k]
                    for i in range(self.num_jobs):
                        if int(nums_ope[i]) <= 1:
                            continue
                        for j in range(int(nums_ope[i]) - 1):
                            step = schedule[num_ope_biases[i] + j]
                            step_next = schedule[num_ope_biases[i] + j + 1]
                            if step[3] > step_next[2]:
                                flag_ope_overlap += 1

        # Check whether there are unscheduled operations
        flag_unscheduled = 0
        for pop in range(self.num_pop):
            for ind in range(self.num_inds):
                schedules_batch = self.schedules_batch[pop][ind]
                for batch_id, schedules in enumerate(schedules_batch):
                    count = 0
                    for i in range(schedules.size(0)):
                        if schedules[i][0] == 1:
                            count += 1
                    add = 0 if (count == self.nums_opes[batch_id]) else 1
                    flag_unscheduled += add

        if flag_ma_overlap + flag_ope_overlap + flag_proc_time + flag_unscheduled != 0:
            return False, self.schedules_batch
        else:
            return True, self.schedules_batch