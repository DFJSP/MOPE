import copy
import json
import subprocess
import random
import time
from collections import deque
import gym
import torch
import numpy as np
from fjsp_env.validate import get_validate_env
from model.EAL import EAL
from fjsp_env.validate import Valid
from fjsp_env.case_generator import CaseGenerator
from openpyxl import Workbook

import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def write_sheet(wb, name, tensor_data, header):
    ws = wb.create_sheet(title=name)
    ws.append(header)
    data = tensor_data.cpu().numpy().round(4)
    for row in data:
        ws.append(row.tolist())

def main():
    # PyTorch initialization
    # device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    device = torch.device("cpu")
    if device.type == 'cuda':
        torch.cuda.set_device(device)
        torch.set_default_tensor_type('torch.cuda.FloatTensor')
    else:
        torch.set_default_tensor_type('torch.FloatTensor')
    print("PyTorch device: ", device.type)
    torch.set_printoptions(precision=None, threshold=np.inf, edgeitems=None, linewidth=None, profile=None, sci_mode=False)

    # 1.读取参数
    with open("./config.json", 'r') as load_f:
        load_dict = json.load(load_f)
    env_paras = load_dict["env_paras"]
    model_paras = load_dict["model_paras"]
    train_paras = load_dict["train_paras"]
    env_paras["device"] = device
    model_paras["device"] = device
    ins_size = env_paras["ins_size"]

    for size in ins_size:
        # 1.Set paras
        num_jobs = size[0]
        num_mas = size[1]

        model_paras["num_jobs"] = env_paras["num_jobs"] = num_jobs
        model_paras["num_mas"] = env_paras["num_mas"] = num_mas
        model_paras["batch_size"] = env_paras["batch_size"]
        model_paras["opes_feat_dim"] = env_paras["opes_feat_dim"]
        model_paras["mas_feat_dim"] = env_paras["mas_feat_dim"]
        model_paras["work_power"] = env_paras["work_power"]
        model_paras["unwork_power"] = env_paras["unwork_power"]
        model_paras["time_of_electric"] = env_paras["time_of_electric"]

        env_paras["num_pop"] = model_paras["num_pop"]
        env_paras["num_individual"] = model_paras["num_individual"]

        env_valid_paras = copy.deepcopy(env_paras)
        env_valid_paras["batch_size"] = env_paras["valid_batch_size"]

        # 设置operations
        opes_per_job_min = int(num_mas * 0.8)
        opes_per_job_max = int(num_mas * 1.2)

        # 2.creat path
        str_time = time.strftime("%Y%m%d_%H%M%S", time.localtime(time.time()))
        save_path = './save/{0}_{1}-train_{2}'.format(num_jobs, num_mas, str_time)
        os.makedirs(save_path, exist_ok=True)
        models_path = os.path.join(save_path, "models")
        os.makedirs(models_path, exist_ok=True)

        """ ---保存信息---"""
        score_path = os.path.join(save_path, "score")
        os.makedirs(score_path, exist_ok=True)

        # 创建验证集
        env_valid = get_validate_env(env_valid_paras)
        state_valid = env_valid.get_state()
        valid = Valid(env_valid_paras)

        # 创建EAL初始种群
        eal_model = EAL(model_paras)

        # 进化训练
        maxlen = 1  # Save the best model
        best_models = deque()
        makespan_best = float('inf')
        env = None
        size_start_time = time.time()
        for i in range(1, train_paras["max_iterations"] + 1):
            # 更换算例
            if (i - 1) % train_paras["change_step"] == 0:
                # 1.创建训练d-fjsp环境
                nums_ope = [random.randint(opes_per_job_min, opes_per_job_max) for _ in range(num_jobs)]
                case_ins = CaseGenerator(env_paras, opes_per_job_min, opes_per_job_max, nums_ope=nums_ope)
                env = gym.make('fjsp-v0', case=case_ins, env_paras=env_paras, data_source='case')

            # 1.读取状态特征
            state = env.get_state()
            # 2.带入d-fjsp env训练
            omega_opes, omega_mas, train_score = eal_model.MPCE(state)

            # 进化验证
            if i % train_paras["validate_step"] == 0:
                print(f"------------------------------------{i}--验证------------------------------")
                print('Start validating')
                valid.reset_env(state=state_valid)
                _value, _Q, v_s = valid.calculate(omega_opes, omega_mas)

                # Save the best model
                if _value < makespan_best:
                    makespan_best = _value
                    if len(best_models) == maxlen:
                        delete_file = best_models.popleft()
                        os.remove(delete_file)
                    save_file = '{0}/save_best_{1}_{2}_{3}.pt'.format(models_path, num_jobs, num_mas, i)
                    best_models.append(save_file)
                    save_dict = {
                        "Q_opes": _Q[0].cpu(),
                        "Q_mas": _Q[1].cpu()}
                    torch.save(save_dict, save_file)
        size_train_time = time.time() - size_start_time
        valid_score = torch.stack(v_s, dim=0)

        # 保存文件
        train_header = ["gene_div", "obj_div", "conv", "score"]
        valid_header = ["makespans", "energy", "daly_time", "sum"]

        wb = Workbook()
        wb.remove(wb.active)

        for p in range(model_paras["num_pop"]):
            write_sheet(wb, f"train_{p}", train_score[p], train_header)
        write_sheet(wb, "valid", valid_score, valid_header)

        ws = wb.create_sheet("time")
        ws.append(["Jobs", "Machines", "Training Time (s)"])
        ws.append([num_jobs, num_mas, round(size_train_time, 4)])

        s_p = score_path + "/scores.xlsx"
        wb.save(s_p)

if __name__ == '__main__':
    main()
