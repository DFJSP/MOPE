import copy
import json
import os
import random
import time as time
import collections
import gym
import torch
import numpy as np
from fjsp_env.validate import Valid
from fjsp_env.fjsp_env import FJSPEnv

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def main():

    # device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    device = torch.device("cpu")
    if device.type=='cuda':
        torch.cuda.set_device(device)
        torch.set_default_tensor_type('torch.cuda.FloatTensor')
    else:
        torch.set_default_tensor_type('torch.FloatTensor')
    print("PyTorch device: ", device.type)
    torch.set_printoptions(precision=None, threshold=np.inf, edgeitems=None, linewidth=None, profile=None, sci_mode=False)

    # Load config and init objects
    with open("./config.json", 'r') as load_f:
        load_dict = json.load(load_f)
    model_paras = load_dict["model_paras"]
    test_paras = load_dict["test_paras"]
    model_paras["device"] = test_paras["device"] = device

    # 从save读取规模算例和对应的模型
    model_path = "./save/"
    model_files = os.listdir(model_path)
    for files in model_files:
        # 1.读取规模大小
        scale = files.split('-')[0]
        num_jobs = int(scale.split('_')[0])
        num_mas = int(scale.split('_')[1])
        model_paras['num_jobs'] = test_paras["num_jobs"] = num_jobs
        model_paras['num_mas'] = test_paras["num_mas"] = num_mas
        num_ins = test_paras['batch_size']
        test_paras["limit_time"] = num_jobs*num_mas

        # 3.读取模型
        folder_path = "./save/" + files + "/models"
        models = os.listdir(folder_path)

        # 4.读取test算例
        # 4.读取test算例
        ins_file_path = "./data/data_test/" + '{0}{1}/'.format(num_jobs, str.zfill(str(num_mas), 2))
        ins_all_files = os.listdir(ins_file_path)
        ins_data_files = ins_all_files[: num_ins]
        ins_data_files_case = ins_data_files.copy()
        for i in range(len(ins_data_files)):
            ins_data_files_case[i] = ins_file_path + ins_data_files[i]
        env = gym.make('fjsp-v0', case=ins_data_files_case, env_paras=test_paras, data_source='file')
        print(f"Create test env: {num_ins}---------------------------------------------------------------------")

        # 5.输入模型参数, 求解
        all_objects = []
        all_solutions = []
        all_times = []
        all_hourly_work_power = []
        all_hourly_idle_power = []
        all_hourly_total_power = []
        all_hourly_price = []
        all_hourly_cost = []
        # 记录每个 solution 的名称
        all_solution_names = []

        sta_time = time.time()
        for i in range(test_paras["iteration"]):        # 遍历
            for mod in models:  # 模型
                if device.type == 'cuda':
                    model_CKPT = torch.load(f"{folder_path}/" + mod, map_location=device)  # 训练好的网络权重
                else:
                    model_CKPT = torch.load(f"{folder_path}/" + mod, map_location='cpu')
                print('loading checkpoint:', mod)
                Q_opes = model_CKPT["Q_opes"]
                Q_mas = model_CKPT["Q_mas"]
                (
                    object,
                    solution,
                    solu_time,
                    hourly_work_power,
                    hourly_idle_power,
                    hourly_total_power,
                    hourly_price,
                    hourly_cost
                ) = schedule(env, Q_opes, Q_mas)

                all_objects.append(object)
                all_solutions.append(solution)
                all_times.append(solu_time)
                all_hourly_work_power.append(hourly_work_power)
                all_hourly_idle_power.append(hourly_idle_power)
                all_hourly_total_power.append(hourly_total_power)
                all_hourly_price.append(hourly_price)
                all_hourly_cost.append(hourly_cost)
                all_solution_names.append(f"{mod}_iteration_{i}")

                env.reset()
                print(f"-----{mod}-iteration-{i}-----")
            tim = time.time() - sta_time
            if tim > test_paras["limit_time"]:
                break
        object_results = torch.stack(all_objects, dim=1)  # (200, 2, 3)
        solution_results = torch.stack(all_solutions, dim=1)  # (200, 2, 14, 6)
        time_results = torch.stack(all_times, dim=1)
        hourly_work_power_results = torch.stack(all_hourly_work_power, dim=1)
        hourly_idle_power_results = torch.stack(all_hourly_idle_power, dim=1)
        hourly_total_power_results = torch.stack(all_hourly_total_power, dim=1)
        hourly_price_results = torch.stack(all_hourly_price, dim=1)
        hourly_cost_results = torch.stack(all_hourly_cost, dim=1)
        # 6. 保存解
        # 2.1处理解的表达
        assigned_jobs = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(list)))
        for i, ins in enumerate(solution_results):      # 算例
            for j, sol in enumerate(ins):               # 解
                for lin in sol:                         # 加工信息
                    mas_id = lin[0].tolist()
                    assigned_jobs[i][j][mas_id].append(lin[1:].tolist())
        save_solution_path = "./data/data_solution/data_solution/" + '{0}{1}/'.format(num_jobs, str.zfill(str(num_mas), 2))
        save_objective_path = "./data/data_solution/data_objective/" + '{0}{1}/'.format(num_jobs, str.zfill(str(num_mas), 2))
        for i, ins in enumerate(ins_data_files):       # 算例
            solution_line_doc = []
            object_line_doc = []
            time_line_doc = []
            save_solution_file = save_solution_path + os.path.splitext(ins)[0] + "/MOPE"    # 解文件名
            save_objective_file = save_objective_path + os.path.splitext(ins)[0] + "/MOPE"  # 解文件名
            for j in range(len(object_results[i])):             # 解数量
                object_line = " ".join([str(val.item()) for val in object_results[i][j]])
                object_line_doc.append(object_line)
                solution_line_doc.append(object_line)
                time_line_doc.append(time_results[i][j].item())
                for m in assigned_jobs[i][j]:                   # 机床
                    solution_line_doc.append(m)
                    for line in assigned_jobs[i][j][m]:
                        solution_line = " ".join([str(int(val)) for val in line])
                        solution_line_doc.append(solution_line)
                solution_line_doc.append('')
            # 2.2保存
            os.makedirs(save_solution_file, exist_ok=True)
            os.makedirs(save_objective_file, exist_ok=True)

            save_hourly_energy_excel(
                save_solution_file,
                hourly_work_power_results[i],
                hourly_idle_power_results[i],
                hourly_total_power_results[i],
                hourly_price_results[i],
                hourly_cost_results[i])

            doc_solution = open(save_solution_file + '/solution.fjs', 'a')
            for i in range(len(solution_line_doc)):
                print(solution_line_doc[i], file=doc_solution)
            doc_solution.close()
            doc_object = open(save_objective_file + '/object.fjs', 'a')
            for i in range(len(object_line_doc)):
                print(object_line_doc[i], file=doc_object)
            doc_object.close()
            doc_time = open(save_objective_file + '/time.fjs', 'a')
            for i in range(len(time_line_doc)):
                print(time_line_doc[i], file=doc_time)
            doc_time.close()

def schedule(env, Q_opes, Q_mas):
    done = False  # 一开始未完成，Unfinished at the beginning
    last_time = time.time()
    while ~done:
        with torch.no_grad():
            jobs_action, mas_action, opes_action = env.action(Q_opes, Q_mas)
            dones = env.step(jobs_action, mas_action, opes_action)
        done = dones.all()
    spend_time = time.time() - last_time  # 解决此环境(实例)所花费的时间,The time taken to solve this environment (instance)
    gantt_result = env.validate_gantt()[0]
    if not gantt_result:
        print("Scheduling Error！！！！！！")
    (hourly_work_power,
     hourly_idle_power,
     hourly_total_power,
     hourly_price,
     hourly_cost) = env.get_hourly_power_and_cost()
    makespan_batch = copy.deepcopy(env.makespan_batch)
    daly_batch = copy.deepcopy(env.daly_time_batch)
    energy_batch = copy.deepcopy(env.energy_batch)
    solution_batch = copy.deepcopy(env.used_batch)
    object = torch.stack([makespan_batch, energy_batch, daly_batch], dim=1)
    sol_time = torch.tensor(spend_time/object.size(0)).expand(object.size(0))
    hourly_work_power_batch = copy.deepcopy(hourly_work_power)
    hourly_idle_power_batch = copy.deepcopy(hourly_idle_power)
    hourly_total_power_batch = copy.deepcopy(hourly_total_power)
    hourly_price_batch = copy.deepcopy(hourly_price)
    hourly_cost_batch = copy.deepcopy(hourly_cost)

    return object, solution_batch, sol_time, hourly_work_power_batch, hourly_idle_power_batch, hourly_total_power_batch, hourly_price_batch, hourly_cost_batch

def save_hourly_energy_excel(
        save_solution_file,
        hourly_work_power,
        hourly_idle_power,
        hourly_total_power,
        hourly_price,
        hourly_cost):
    wb = Workbook()
    wb.remove(wb.active)

    data_dict = {
        "WorkPower": hourly_work_power,
        "IdlePower": hourly_idle_power,
        "TotalPower": hourly_total_power,
        "Price": hourly_price,
        "Cost": hourly_cost
    }
    for sheet_name, tensor_data in data_dict.items():
        ws = wb.create_sheet(sheet_name)
        data = tensor_data.detach().cpu().numpy()
        # [solution, hour]
        num_solution, num_hour = data.shape
        # 第一列/行
        ws.cell(row=1, column=1, value="Hour")
        for s in range(num_solution):
            ws.cell(
                row=1,
                column=s + 2,
                value=f"Solution_{s}"
            )
        for h in range(num_hour):
            ws.cell(
                row=h + 2,
                column=1,
                value=h
            )
            for s in range(num_solution):
                ws.cell(
                    row=h + 2,
                    column=s + 2,
                    value=float(data[s, h])
                )
    excel_path = os.path.join(
        save_solution_file,
        "hourly_energy.xlsx"
    )
    wb.save(excel_path)

if __name__ == '__main__':
    main()