import json
import random
import os
import numpy as np

class CaseMake:
    '''
    FJSP instance generator
    '''
    def __init__(self, paras, num_jobs, num_mas, opes_per_job_min, opes_per_job_max, nums_ope=None,
                 path='./make_data_ins/', flag_same_opes=True, flag_doc=True):
        if nums_ope is None:
            nums_ope = []
        self.flag_doc = flag_doc  # Whether save the instance to a file
        self.flag_same_opes = flag_same_opes
        self.nums_ope = nums_ope
        self.path = path + '{0}{1}/'.format(num_jobs, str.zfill(str(num_mas), 2)) # Instance save path (relative path)
        os.makedirs(self.path, exist_ok=True)
        self.num_jobs = num_jobs
        self.num_mas = num_mas
        self.eave = paras["eave"]

        self.mas_per_ope_min = 2  # The minimum number of machines that can process an operation
        self.mas_per_ope_max = self.num_mas
        self.opes_per_job_min = opes_per_job_min  # The minimum number of operations for a job
        self.opes_per_job_max = opes_per_job_max
        self.proctime_per_ope_min = 1  # Minimum average processing time
        self.proctime_per_ope_max = 20
        self.proctime_unope_min = 1
        self.proctime_unope_max = 8
        self.proctime_dev = 0.2


    def get_case(self, idx=0):
        '''
        Generate FJSP instance
        :param idx: The instance number
        '''
        if not self.flag_same_opes:
            self.nums_ope = [random.randint(self.opes_per_job_min, self.opes_per_job_max) for _ in range(self.num_jobs)]
        self.num_opes = sum(self.nums_ope)
        self.nums_option = [random.randint(self.mas_per_ope_min, self.mas_per_ope_max) for _ in
                            range(self.num_opes)]
        self.num_options = sum(self.nums_option)
        self.ope_ma = []
        for val in self.nums_option:
            self.ope_ma = self.ope_ma + sorted(random.sample(range(1, self.num_mas + 1), val))  # 分机床
        self.proc_time = []
        self.proc_times_mean = [random.randint(self.proctime_per_ope_min, self.proctime_per_ope_max) for _ in
                                range(self.num_opes)]
        self.num_ope_biass = [sum(self.nums_ope[0:i]) for i in range(self.num_jobs)]
        self.num_ma_biass = [sum(self.nums_option[0:i]) for i in range(self.num_opes)]
        # 为每个job的工序定义加工时间
        for i in range(len(self.nums_option)):
            low_bound = max(self.proctime_per_ope_min, round(self.proc_times_mean[i] * (1 - self.proctime_dev)))
            high_bound = min(self.proctime_per_ope_max, round(self.proc_times_mean[i] * (1 + self.proctime_dev)))
            proc_time_ope = [random.randint(low_bound, high_bound) for _ in range(self.nums_option[i])]
            self.proc_time = self.proc_time + proc_time_ope

        # 设置job的到达时间符合Poisson分布
        arrival_time = np.zeros(self.num_jobs)
        lam = 1.0 / self.eave
        inter_arrivals = np.random.exponential(scale=self.eave, size=self.num_jobs - 1)
        inter_arrivals = np.maximum(1, np.rint(inter_arrivals).astype(int))
        arrival_time[1:] = np.cumsum(inter_arrivals)

        # 计算每个job的最大完成时间，平均完成时间，定义due_time
        max_jobs_time = [0 for _ in range(self.num_jobs)]
        mean_jobs_time = [0 for _ in range(self.num_jobs)]
        n = 0
        for j, o in zip(range(self.num_jobs), self.nums_ope):
            for ma in self.nums_option[self.num_ope_biass[j]:self.num_ope_biass[j] + o]:
                max_ope_time = max(self.proc_time[n:n + ma])
                mean_ope_time = round(sum(self.proc_time[n:n + ma]) / ma, 1)
                n = ma + n
                max_jobs_time[j] = max_jobs_time[j] + max_ope_time
                mean_jobs_time[j] = mean_jobs_time[j] + mean_ope_time
        due_time = []
        for i in range(self.num_jobs):
            d_t = arrival_time[i] + max_jobs_time[i]
            due_time.append(d_t)

        line_0 = '{0}\t{1}\t{2}'.format(self.num_jobs, self.num_mas, self.num_options / self.num_opes)
        line_1 = (" ".join([str(val) for val in due_time]))
        line_2 = (" ".join([str(val) for val in arrival_time]))

        lines = []
        lines_doc = []
        lines.append(line_0)
        lines.append(line_1)
        lines.append(line_2)
        lines_doc.append(line_0)
        lines_doc.append(line_1)
        lines_doc.append(line_2)

        for i in range(self.num_jobs):
            flag = 0
            flag_time = 0
            flag_new_ope = 1
            idx_ope = -1
            idx_ma = 0
            line = []
            option_max = sum(self.nums_option[self.num_ope_biass[i]:(
                        self.num_ope_biass[i] + self.nums_ope[i])])
            idx_option = 0
            while True:
                if flag == 0:
                    line.append(self.nums_ope[i])
                    flag += 1
                elif flag == flag_new_ope:
                    idx_ope += 1
                    idx_ma = 0
                    flag_new_ope += self.nums_option[self.num_ope_biass[i] + idx_ope] * 2 + 1
                    line.append(self.nums_option[self.num_ope_biass[i] + idx_ope])
                    flag += 1
                elif flag_time == 0:
                    line.append(self.ope_ma[self.num_ma_biass[self.num_ope_biass[i] + idx_ope] + idx_ma])
                    flag += 1
                    flag_time = 1
                else:
                    line.append(self.proc_time[self.num_ma_biass[self.num_ope_biass[i] + idx_ope] + idx_ma])
                    flag += 1
                    flag_time = 0
                    idx_option += 1
                    idx_ma += 1
                if idx_option == option_max:
                    str_line = " ".join([str(val) for val in line])
                    lines_doc.append(str_line)
                    lines.append(str_line)
                    break
        lines.append('\n')
        if self.flag_doc:
            doc = open(self.path + '{0}j_{1}m_{2}.fjs'.format(self.num_jobs, self.num_mas, str.zfill(str(idx + 1), 3)),'a')
            for i in range(len(lines_doc)):
                print(lines_doc[i], file=doc)
            doc.close()
def main():
    with open("./config_make_d-fjsp.json", 'r') as load_f:
        load_dict = json.load(load_f)
    make_paras = load_dict["make_paras"]
    ins_size = make_paras["ins_size"]
    num_ins = make_paras["num_ins"]

    print("开始生成FJSP实例...")
    for ins in ins_size:
        num_jobs = ins[0]
        num_mas = ins[1]

        opes_per_job_min = int(num_mas * 0.8)
        opes_per_job_max = int(num_mas * 1.2)

        nums_ope = [random.randint(opes_per_job_min, opes_per_job_max) for _ in range(num_jobs)]
        case = CaseMake(make_paras, num_jobs, num_mas, opes_per_job_min, opes_per_job_max, nums_ope=nums_ope)

        for i in range(num_ins):
            case.get_case(i)
            print(f"Completed {i} instance")


if __name__ == '__main__':
    main()
